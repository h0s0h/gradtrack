'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/components/auth/AuthProvider';
import { supabase } from '@/lib/supabase/client';

export default function NewProjectPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();

  // حالات الإدخال
  const [formData, setFormData] = useState({ name: '', description: '', supervisors: '' });
  const [formErrors, setFormErrors] = useState({ name: '' });
  const [invitations, setInvitations] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [lastSearchTerm, setLastSearchTerm] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  // تحقق من اسم المشروع
  const validateProjectName = (name) => {
    if (!name.trim()) return 'اسم المشروع مطلوب';
    if (name.length < 3) return 'اسم المشروع يجب أن يكون 3 أحرف على الأقل';
    return '';
  };

  // تعامل مع تغييرات الحقول
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if (name === 'name') {
      setFormErrors(prev => ({ ...prev, name: validateProjectName(value) }));
    }
    if (name === 'supervisors') {
      const words = value.split(' ');
      const lastWord = words[words.length - 1];
      if (lastWord.startsWith('@')) setLastSearchTerm(lastWord);
      else setSearchResults([]);
    }
  };

  // بحث المستخدمين
  useEffect(() => {
    if (!lastSearchTerm) {
      setSearchResults([]);
      return;
    }
    const timeout = setTimeout(() => {
      searchUsers(lastSearchTerm);
    }, 300);
    return () => clearTimeout(timeout);
  }, [lastSearchTerm]);

  const searchUsers = async (query) => {
    if (!query.startsWith('@')) return;
    try {
      setIsSearching(true);
      const term = query.substring(1).toLowerCase();
      if (term.length < 2) {
        setSearchResults([]);
        return;
      }
      const { data, error } = await supabase
        .from('users')
        .select('id, email, full_name, avatar_url')
        .or(`email.ilike.%${term}%,full_name.ilike.%${term}%`)
        .limit(5);
      if (error) throw error;
      const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(term);
      if (isEmail) {
        const exists = data.some(u => u.email.toLowerCase() === term);
        if (!exists) {
          setSearchResults([...(data || []), { id: 'invite', email: term, full_name: `دعوة ${term}`, isInvitation: true }]);
          return;
        }
      }
      setSearchResults(data || []);
    } catch (e) {
      console.error(e);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  // اختيار مستخدم أو دعوة
  const handleUserSelect = (u) => {
    const words = formData.supervisors.split(' ');
    words.pop();
    let newVal;
    if (u.isInvitation) {
      if (!invitations.find(inv => inv.email === u.email)) {
        setInvitations(prev => [...prev, { email: u.email, role: 'supervisor' }]);
      }
      newVal = [...words, `@${u.email} [دعوة]`, ''].join(' ');
    } else {
      const name = u.full_name || u.email;
      newVal = [...words, `@${name}`, ''].join(' ');
    }
    setFormData(prev => ({ ...prev, supervisors: newVal }));
    setSearchResults([]);
  };

  // إزالة دعوة
  const removeInvitation = (email) => {
    setInvitations(prev => prev.filter(inv => inv.email !== email));
    const pattern = new RegExp(`@${email}\\s\\[دعوة\\]`, 'g');
    setFormData(prev => ({ ...prev, supervisors: prev.supervisors.replace(pattern, '').trim() }));
  };

  // إنشاء كود دعوة فريد
  const generateUniqueInviteCode = () => {
    // إنشاء كود دعوة أكثر تعقيدًا وفريدًا
    const timestamp = new Date().getTime().toString(36);
    const randomStr = Math.random().toString(36).substring(2, 10);
    return `${timestamp}-${randomStr}`;
  };

  // إرسال دعوة عبر البريد
  const sendInvitation = async (email, projectId, role = 'supervisor') => {
    try {
      // إنشاء كود دعوة فريد
      const code = generateUniqueInviteCode();
      
      // التحقق من عدم وجود دعوة سابقة لنفس البريد الإلكتروني ونفس المشروع
      const { data: existingInvites, error: checkError } = await supabase
        .from('project_invitations')
        .select('id')
        .eq('project_id', projectId)
        .eq('email', email);
      
      if (checkError) throw checkError;
      
      // إذا كانت هناك دعوة سابقة، قم بتحديثها بدلاً من إنشاء دعوة جديدة
      if (existingInvites && existingInvites.length > 0) {
        const { error: updateError } = await supabase
          .from('project_invitations')
          .update({ 
            role: role, 
            invite_code: code, 
            invited_by: user.id,
            accepted: false,
            expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // تنتهي بعد 7 أيام
          })
          .eq('id', existingInvites[0].id);
          
        if (updateError) throw updateError;
      } else {
        // إنشاء دعوة جديدة
        const { error: insertError } = await supabase
          .from('project_invitations')
          .insert({ 
            project_id: projectId, 
            email: email, 
            role: role, 
            invite_code: code, 
            invited_by: user.id 
          });
          
        if (insertError) throw insertError;
      }
      
      return true;
    } catch (error) {
      console.error('Error sending invitation:', error);
      return false;
    }
  };

  // استخراج الإشارات
  const extractMentions = (text) => {
    const matches = text.match(/@(\S+)(?:\s\[دعوة\])?/g) || [];
    return matches.map(m => m.replace('@', '').replace(' [دعوة]', ''));
  };
  const isInvitationMention = (text, name) => new RegExp(`@${name}\\s\\[دعوة\\]`).test(text);

  // إنشاء المشروع
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // التحقق من صحة البيانات
    const nameErr = validateProjectName(formData.name);
    if (nameErr) {
      setFormErrors({ name: nameErr });
      return;
    }
    
    // التحقق من تسجيل الدخول
    if (!user) {
      setError('يجب تسجيل الدخول لإنشاء مشروع');
      return;
    }
    
    try {
      setIsSubmitting(true);
      setError(null);
      
      // إنشاء المشروع - لا نحتاج لتحديد created_at لأنه يتم تعيينه تلقائيًا في قاعدة البيانات
      const { data: projData, error: projErr } = await supabase
        .from('projects')
        .insert({ 
          name: formData.name, 
          description: formData.description || '', 
          owner_id: user.id 
        })
        .select();
      
      if (projErr) throw projErr;
      
      // التحقق من نجاح إنشاء المشروع
      if (!projData || projData.length === 0) {
        throw new Error('فشل إنشاء المشروع، لم يتم إرجاع بيانات المشروع');
      }
      
      const newProj = projData[0];
      
      // إضافة مشرفين موجودين - تحسين الكود لمعالجة الإضافات بشكل متوازي
      const supervisorPromises = [];
      if (formData.supervisors) {
        const mentions = extractMentions(formData.supervisors);
        for (const name of mentions) {
          // تخطي الدعوات، سيتم معالجتها لاحقًا
          if (isInvitationMention(formData.supervisors, name)) continue;
          
          // البحث عن المستخدم وإضافته كمشرف
          const promise = supabase
            .from('users')
            .select('id')
            .or(`email.ilike.${name},full_name.ilike.${name}`)
            .limit(1)
            .then(({ data: uData, error: uErr }) => {
              if (uErr || !uData || !uData.length) return null;
              
              // إضافة المستخدم كمشرف في المشروع
              return supabase
                .from('project_members')
                .insert({ 
                  project_id: newProj.id, 
                  user_id: uData[0].id, 
                  role: 'supervisor' 
                })
                .then(({ error }) => {
                  if (error) console.error('Error adding supervisor:', error);
                  return !error;
                });
            });
          
          supervisorPromises.push(promise);
        }
      }
      
      // انتظار اكتمال إضافة المشرفين
      await Promise.all(supervisorPromises);
      
      // إرسال دعوات جديدة - تحسين الكود لمعالجة الدعوات بشكل متوازي
      const invitationPromises = invitations.map(inv => 
        sendInvitation(inv.email, newProj.id, inv.role)
      );
      
      // انتظار اكتمال إرسال الدعوات
      const invitationResults = await Promise.all(invitationPromises);
      const successInvCount = invitationResults.filter(result => result).length;
      
      // عرض رسالة النجاح
      setSuccess(`تم إنشاء المشروع${successInvCount ? ` وتم إرسال ${successInvCount} دعوات` : ''}`);
      
      // الانتقال إلى صفحة المشروع بعد إكمال جميع العمليات
      router.push(`/project/${newProj.id}`);
      
    } catch (e) {
      console.error('Error creating project:', e);
      setError(e.message || 'حدث خطأ أثناء إنشاء المشروع');
    } finally {
      setIsSubmitting(false);
    }
  };

  // متغيرات الحركات
  const containerVariants = { hidden: { opacity: 0 }, visible: { opacity: 1, transition: { when: 'beforeChildren', staggerChildren: 0.1 } } };
  const itemVariants = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
  const buttonVariants = { hover: { scale: 1.05, boxShadow: '0px 5px 10px rgba(0, 0, 0, 0.1)' }, tap: { scale: 0.95 } };

  // عرض أثناء التحميل
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center"><motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"/></div>;
  }
  // إذا لم يكن مسجلاً
  if (!user) {
    return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h2 className="text-2xl font-bold mb-4">يجب تسجيل الدخول لإنشاء مشروع جديد</h2><Link href="/auth/login" className="inline-block bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition">تسجيل الدخول</Link></div></div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* الشريط العلوي */}
      <motion.header initial={{ y: -50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5 }} className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <motion.div whileHover={{ x: -3 }} whileTap={{ scale: 0.9 }}>
            <Link href="/dashboard" className="text-indigo-600 hover:text-indigo-800 mr-4"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></Link>
          </motion.div>
          <h1 className="text-2xl font-bold text-gray-800">إنشاء مشروع جديد</h1>
          <motion.div whileHover={{ scale: 1.03 }} className="flex items-center space-x-4 rtl:space-x-reverse">
            <Link href="/profile" className="flex items-center">
              <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center mr-2">
                {user.avatar_url ? <img src={user.avatar_url} alt={user.full_name} className="w-8 h-8 rounded-full"/> : <span className="text-indigo-600 font-semibold">{(user.full_name||user.email).charAt(0)}</span>}
              </div>
              <span className="text-gray-700">{user.full_name || user.email}</span>
            </Link>
          </motion.div>
        </div>
      </motion.header>

      {/* المحتوى الرئيسي */}
      <main className="container mx-auto px-4 py-8">
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="max-w-2xl mx-auto">
          <AnimatePresence>{error && <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-red-50 text-red-700 p-4 rounded-md mb-6 flex items-center"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 001.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd"/></svg>{error}</motion.div>}</AnimatePresence>
          <AnimatePresence>{success && <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-green-50 text-green-700 p-4 rounded-md mb-6 flex items-center"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/></svg>{success}</motion.div>}</AnimatePresence>

          <motion.div variants={itemVariants} className="bg-white rounded-lg shadow-md p-6">
            <form onSubmit={handleSubmit}>
              {/* اسم المشروع */}
              <motion.div variants={itemVariants} className="mb-6">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">اسم المشروع *</label>
                <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} className={`w-full px-3 py-2 border ${formErrors.name? 'border-red-500':'border-gray-300'} rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500`} placeholder="أدخل اسم المشروع" dir="rtl"/>
                <AnimatePresence>{formErrors.name && <motion.p initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mt-1 text-sm text-red-600">{formErrors.name}</motion.p>}</AnimatePresence>
              </motion.div>
              {/* وصف المشروع */}
              <motion.div variants={itemVariants} className="mb-6">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">وصف المشروع (اختياري)</label>
                <textarea id="description" name="description" value={formData.description} onChange={handleChange} rows={4} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="أدخل وصفاً للمشروع" dir="rtl"></textarea>
              </motion.div>
              {/* المشرفون */}
              <motion.div variants={itemVariants} className="mb-6">
                <label htmlFor="supervisors" className="block text-sm font-medium text-gray-700 mb-1">المشرفون (اختياري)</label>
                <div className="relative">
                  <textarea id="supervisors" name="supervisors" value={formData.supervisors} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="أضف مشرفين باستخدام @اسم_المستخدم أو @email@example.com" dir="rtl"></textarea>
                  {isSearching && <motion.div initial={{ opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="absolute right-3 top-3"><motion.div animate={{rotate:360}} transition={{duration:1, repeat:Infinity, ease:'linear'}} className="rounded-full h-4 w-4 border-t-2 border-b-2 border-indigo-500"/></motion.div>}
                  {searchResults.length>0 && <motion.div initial={{opacity:0,y:-10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-10}} className="absolute z-10 w-full mt-1 bg-white rounded-md shadow-lg border border-gray-200"><ul className="py-1">{searchResults.map(u=> <li key={u.id} className="px-3 py-2 cursor-pointer flex items-center hover:bg-gray-100" onClick={()=>handleUserSelect(u)}><div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center ml-2">{u.isInvitation? <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>: u.avatar_url? <img src={u.avatar_url} alt={u.full_name} className="w-8 h-8 rounded-full"/>: <span className="text-indigo-600 font-semibold">{(u.full_name||u.email).charAt(0)}</span>}</div><div><p className="text-gray-800">{u.isInvitation? 'دعوة مستخدم جديد': u.full_name|| 'بدون اسم'}</p><p className="text-xs text-gray-500">{u.email}</p></div></li>)}</ul></motion.div>}
                </div>
                {invitations.length>0 && <motion.div initial={{opacity:0,height:0}} animate={{opacity:1,height:'auto'}} className="mt-3"><p className="text-sm font-medium text-gray-700 mb-2">الدعوات:</p><div className="flex flex-wrap gap-2">{invitations.map((inv,i)=><div key={i} className="bg-indigo-50 text-indigo-700 rounded-full px-3 py-1 flex items-center text-sm"><span>{inv.email}</span><button type="button" onClick={()=>removeInvitation(inv.email)} className="ml-2 text-indigo-500 hover:text-indigo-700"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg></button></div>)}</div></motion.div>}
              </motion.div>

              <motion.div variants={itemVariants} className="flex justify-end">
                <motion.button type="submit" variants={buttonVariants} whileHover="hover" whileTap="tap" disabled={isSubmitting} className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition disabled:opacity-70">
                  {isSubmitting? <span className="flex items-center"><motion.svg animate={{rotate:360}} transition={{duration:1,repeat:Infinity,ease:'linear'}} className="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></motion.svg>جاري الإنشاء...</span>: 'إنشاء المشروع'}
                </motion.button>
              </motion.div>
            </form>
          </motion.div>
        </motion.div>
      </main>
    </div>
  );
}
