'use client'
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';    
import Link from 'next/link';

// Types
interface User {
  id: string;
  full_name: string;
  avatar_url: string | null;
  email: string;
}

interface Project {
  id: string;
  name: string;
}

interface CreateTaskProps {
  projectId?: string; // Si fourni, la tâche sera créée pour ce projet spécifique
}

// Composant Button personnalisé
const Button = ({ children, primary, href, onClick, type = 'button', disabled = false, className = '', ...props }: {
  children: React.ReactNode;
  primary?: boolean;
  href?: string;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
  className?: string;
  [key: string]: any;
}) => {
  const baseClasses = "font-medium rounded-lg px-4 py-2 transition-colors";
  const colorClasses = primary 
    ? "bg-gradient-to-r from-blue-600 to-indigo-700 text-white hover:from-blue-700 hover:to-indigo-800 shadow-md" 
    : "text-gray-700 hover:bg-gray-100";
  const disabledClasses = disabled ? "opacity-50 cursor-not-allowed" : "";
  
  const buttonClasses = `${baseClasses} ${colorClasses} ${disabledClasses} ${className}`;
  
  if (href && !disabled) {
    return (
      <Link href={href} className={buttonClasses} {...props}>
        {children}
      </Link>
    );
  }
  
  return (
    <button 
      type={type} 
      className={buttonClasses} 
      onClick={onClick} 
      disabled={disabled} 
      {...props}
    >
      {children}
    </button>
  );
};

// Composant principal
const CreateTask: React.FC<CreateTaskProps> = ({ projectId }) => {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectMembers, setProjectMembers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  
  // État du formulaire
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'not_started',
    priority: 'medium',
    dueDate: '',
    assignedTo: '',
    projectId: projectId || ''
  });
  
  // Effet pour charger l'utilisateur actuel
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const { data: { user }, error: authError } = await supabase.auth.getUser();
        
        if (authError) {
          console.error('Error fetching auth user:', authError);
          setError('حدث خطأ أثناء التحقق من المستخدم');
          return;
        }
        
        if (user) {
          const { data, error } = await supabase
            .from('users')
            .select('id, full_name, avatar_url, email')
            .eq('id', user.id)
            .single();
          
          if (error) {
            console.error('Error fetching user:', error);
            setError('حدث خطأ أثناء تحميل بيانات المستخدم');
            return;
          }
          
          setUser(data);
        } else {
          // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
          router.push('/login');
        }
      } catch (err) {
        console.error('Unexpected error:', err);
        setError('حدث خطأ غير متوقع');
      }
    };
    
    fetchCurrentUser();
  }, [router]);
  
  // Effet pour charger les projets si projectId n'est pas fourni
  useEffect(() => {
    if (projectId) {
      setFormData(prev => ({ ...prev, projectId }));
      return;
    }
    
    const fetchProjects = async () => {
      if (!user) return;
      
      try {
        setIsLoading(true);
        
        const { data: membershipsData, error: membershipsError } = await supabase
          .from('project_members')
          .select('*, project:project_id(*)')
          .eq('user_id', user.id);
        
        if (membershipsError) {
          console.error('Error fetching projects:', membershipsError);
          setError('حدث خطأ أثناء تحميل المشاريع');
          return;
        }
        
        if (!membershipsData || membershipsData.length === 0) {
          setProjects([]);
          return;
        }
        
        const projectsList = membershipsData
          .filter(membership => membership.project) // Filtrer les projets null
          .map(membership => ({
            id: membership.project.id,
            name: membership.project.name
          }));
        
        setProjects(projectsList);
        
        // Si l'utilisateur n'a qu'un seul projet, le sélectionner par défaut
        if (projectsList.length === 1) {
          setFormData(prev => ({ ...prev, projectId: projectsList[0].id }));
        }
      } catch (error) {
        console.error('Error fetching projects:', error);
        setError('حدث خطأ أثناء تحميل المشاريع');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProjects();
  }, [user, projectId]);
  
  // Effet pour charger les membres du projet lorsque projectId change
  useEffect(() => {
    const fetchProjectMembers = async () => {
      if (!formData.projectId) {
        setProjectMembers([]);
        return;
      }
      
      try {
        setIsLoading(true);
        
        const { data: membersData, error: membersError } = await supabase
          .from('project_members')
          .select('*, user:user_id(*)')
          .eq('project_id', formData.projectId);
        
        if (membersError) {
          console.error('Error fetching project members:', membersError);
          setError('حدث خطأ أثناء تحميل أعضاء المشروع');
          return;
        }
        
        if (!membersData || membersData.length === 0) {
          setProjectMembers([]);
          return;
        }
        
        const membersList = membersData
          .filter(membership => membership.user) // Filtrer les utilisateurs null
          .map(membership => ({
            id: membership.user.id,
            full_name: membership.user.full_name,
            avatar_url: membership.user.avatar_url,
            email: membership.user.email
          }));
        
        setProjectMembers(membersList);
      } catch (error) {
        console.error('Error fetching project members:', error);
        setError('حدث خطأ أثناء تحميل أعضاء المشروع');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProjectMembers();
  }, [formData.projectId]);
  
  // Gérer les changements dans le formulaire
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Réinitialiser les messages d'erreur lors de la modification du formulaire
    setError(null);
  };
  
  // Soumettre le formulaire
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      setError('يجب تسجيل الدخول لإنشاء مهمة');
      return;
    }
    
    if (!formData.projectId) {
      setError('يرجى اختيار مشروع');
      return;
    }
    
    if (!formData.title.trim()) {
      setError('يرجى إدخال عنوان للمهمة');
      return;
    }
    
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);
    
    try {
      // Préparer les données de la tâche
      const taskData = {
        project_id: formData.projectId,
        title: formData.title.trim(),
        description: formData.description.trim() || null,
        status: formData.status,
        priority: formData.priority,
        due_date: formData.dueDate || null,
        assigned_to: formData.assignedTo || null,
        created_by: user.id,
        completion_percentage: formData.status === 'completed' ? 100 : formData.status === 'not_started' ? 0 : 50
      };
      
      // Insérer la tâche dans la base de données
      const { data: newTask, error: insertError } = await supabase
        .from('tasks')
        .insert(taskData)
        .select()
        .single();
      
      if (insertError) {
        console.error('Error creating task:', insertError);
        setError('حدث خطأ أثناء إنشاء المهمة: ' + insertError.message);
        return;
      }
      
      if (!newTask) {
        setError('حدث خطأ أثناء إنشاء المهمة: لم يتم إرجاع بيانات المهمة');
        return;
      }
      
      // Afficher un message de succès
      setSuccessMessage('تم إنشاء المهمة بنجاح');
      
      // Réinitialiser le formulaire
      setFormData({
        title: '',
        description: '',
        status: 'not_started',
        priority: 'medium',
        dueDate: '',
        assignedTo: '',
        projectId: formData.projectId
      });
      
      // Rediriger vers la page de la tâche après un court délai
      setTimeout(() => {
        router.push(`/tasks/${newTask.id}`);
      }, 1500);
    } catch (error: any) {
      console.error('Error creating task:', error);
      setError('حدث خطأ أثناء إنشاء المهمة: ' + (error.message || 'خطأ غير معروف'));
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">إنشاء مهمة جديدة</h2>
      
      {error && (
        <div className="bg-red-50 text-red-700 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}
      
      {successMessage && (
        <div className="bg-green-50 text-green-700 p-4 rounded-lg mb-6">
          {successMessage}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Sélection du projet (si projectId n'est pas fourni) */}
        {!projectId && (
          <div>
            <label htmlFor="projectId" className="block text-sm font-medium text-gray-700 mb-1">
              المشروع *
            </label>
            <select
              id="projectId"
              name="projectId"
              value={formData.projectId}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
              disabled={isLoading}
            >
              <option value="">اختر مشروعًا</option>
              {projects.map(project => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
          </div>
        )}
        
        {/* Titre de la tâche */}
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
            عنوان المهمة *
          </label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            required
            disabled={isLoading}
          />
        </div>
        
        {/* Description de la tâche */}
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
            وصف المهمة
          </label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={4}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            disabled={isLoading}
          />
        </div>
        
        {/* Statut de la tâche */}
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
            حالة المهمة
          </label>
          <select
            id="status"
            name="status"
            value={formData.status}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            disabled={isLoading}
          >
            <option value="not_started">لم تبدأ</option>
            <option value="in_progress">قيد التنفيذ</option>
            <option value="completed">مكتملة</option>
            <option value="delayed">متأخرة</option>
          </select>
        </div>
        
        {/* Priorité de la tâche */}
        <div>
          <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
            أولوية المهمة
          </label>
          <select
            id="priority"
            name="priority"
            value={formData.priority}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            disabled={isLoading}
          >
            <option value="low">منخفضة</option>
            <option value="medium">متوسطة</option>
            <option value="high">عالية</option>
          </select>
        </div>
        
        {/* Date d'échéance */}
        <div>
          <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700 mb-1">
            تاريخ الاستحقاق
          </label>
          <input
            type="datetime-local"
            id="dueDate"
            name="dueDate"
            value={formData.dueDate}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            disabled={isLoading}
          />
        </div>
        
        {/* Assignation à un membre */}
        <div>
          <label htmlFor="assignedTo" className="block text-sm font-medium text-gray-700 mb-1">
            تكليف إلى
          </label>
          <select
            id="assignedTo"
            name="assignedTo"
            value={formData.assignedTo}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            disabled={isLoading}
          >
            <option value="">غير مكلف</option>
            {projectMembers.map(member => (
              <option key={member.id} value={member.id}>
                {member.full_name}
              </option>
            ))}
          </select>
        </div>
        
        {/* Boutons d'action */}
        <div className="flex justify-end space-x-4 space-x-reverse">
          <Button 
            type="button" 
            onClick={() => router.back()}
            disabled={isLoading}
          >
            إلغاء
          </Button>
          <Button 
            type="submit" 
            primary 
            disabled={isLoading}
          >
            {isLoading ? 'جاري الإنشاء...' : 'إنشاء المهمة'}
          </Button>
        </div>
      </form>
    </div>
  );
};

// Page Next.js
export default function CreateTaskPage({ params }: { params?: { projectId?: string } }) {
  return (
    <div className="container mx-auto py-8 px-4">
      <CreateTask projectId={params?.projectId} />
    </div>
  );
}
