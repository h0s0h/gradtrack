(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_auth_signup_page_tsx_c61d05c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_auth_signup_page_tsx_c61d05c3._.js",
  "chunks": [
    "static/chunks/node_modules_3aa641cb._.js",
    "static/chunks/src_app_auth_signup_page_tsx_178bf7fa._.js"
  ],
  "source": "dynamic"
});
