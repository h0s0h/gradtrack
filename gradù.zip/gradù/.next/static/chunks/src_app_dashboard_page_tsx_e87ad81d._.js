(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_dashboard_page_tsx_e87ad81d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_dashboard_page_tsx_e87ad81d._.js",
  "chunks": [
    "static/chunks/src_0efacc7f._.js",
    "static/chunks/node_modules_lodash_90f72504._.js",
    "static/chunks/node_modules_recharts_es6_9b3940b2._.js",
    "static/chunks/node_modules_5e82a6e7._.js"
  ],
  "source": "dynamic"
});
