(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_tasks_[id]_page_tsx_dfefb0b7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_tasks_[id]_page_tsx_dfefb0b7._.js",
  "chunks": [
    "static/chunks/src_app_tasks_[id]_page_tsx_aaa29562._.js",
    "static/chunks/node_modules_date-fns_0240af3c._.js"
  ],
  "source": "dynamic"
});
