(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_b4714161._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_b4714161._.js",
  "chunks": [
    "static/chunks/[root of the server]__6278be39._.js",
    "static/chunks/src_71c37cef._.js",
    "static/chunks/node_modules_@supabase_auth-js_dist_module_33324aae._.js",
    "static/chunks/node_modules_framer-motion_dist_es_d12c975d._.js",
    "static/chunks/node_modules_motion-dom_dist_es_7fc0833b._.js",
    "static/chunks/node_modules_60cd0089._.js",
    "static/chunks/src_app_globals_b805903d.css"
  ],
  "source": "dynamic"
});
