(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app_tasks_new_page_tsx_12e0bb6e._.js", {

"[project]/src/app/tasks/new/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CreateTaskPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
// Composant Button personnalisé
const Button = ({ children, primary, href, onClick, type = 'button', disabled = false, className = '', ...props })=>{
    const baseClasses = "font-medium rounded-lg px-4 py-2 transition-colors";
    const colorClasses = primary ? "bg-gradient-to-r from-blue-600 to-indigo-700 text-white hover:from-blue-700 hover:to-indigo-800 shadow-md" : "text-gray-700 hover:bg-gray-100";
    const disabledClasses = disabled ? "opacity-50 cursor-not-allowed" : "";
    const buttonClasses = `${baseClasses} ${colorClasses} ${disabledClasses} ${className}`;
    if (href && !disabled) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            className: buttonClasses,
            ...props,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/app/tasks/new/page.tsx",
            lineNumber: 45,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: type,
        className: buttonClasses,
        onClick: onClick,
        disabled: disabled,
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/app/tasks/new/page.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
};
_c = Button;
// Composant principal
const CreateTask = ({ projectId })=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [projectMembers, setProjectMembers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [successMessage, setSuccessMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // État du formulaire
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        title: '',
        description: '',
        status: 'not_started',
        priority: 'medium',
        dueDate: '',
        assignedTo: '',
        projectId: projectId || ''
    });
    // Effet pour charger l'utilisateur actuel
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CreateTask.useEffect": ()=>{
            const fetchCurrentUser = {
                "CreateTask.useEffect.fetchCurrentUser": async ()=>{
                    try {
                        const { data: { user }, error: authError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.getUser();
                        if (authError) {
                            console.error('Error fetching auth user:', authError);
                            setError('حدث خطأ أثناء التحقق من المستخدم');
                            return;
                        }
                        if (user) {
                            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('users').select('id, full_name, avatar_url, email').eq('id', user.id).single();
                            if (error) {
                                console.error('Error fetching user:', error);
                                setError('حدث خطأ أثناء تحميل بيانات المستخدم');
                                return;
                            }
                            setUser(data);
                        } else {
                            // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
                            router.push('/login');
                        }
                    } catch (err) {
                        console.error('Unexpected error:', err);
                        setError('حدث خطأ غير متوقع');
                    }
                }
            }["CreateTask.useEffect.fetchCurrentUser"];
            fetchCurrentUser();
        }
    }["CreateTask.useEffect"], [
        router
    ]);
    // Effet pour charger les projets si projectId n'est pas fourni
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CreateTask.useEffect": ()=>{
            if (projectId) {
                setFormData({
                    "CreateTask.useEffect": (prev)=>({
                            ...prev,
                            projectId
                        })
                }["CreateTask.useEffect"]);
                return;
            }
            const fetchProjects = {
                "CreateTask.useEffect.fetchProjects": async ()=>{
                    if (!user) return;
                    try {
                        setIsLoading(true);
                        const { data: membershipsData, error: membershipsError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('project_members').select('*, project:project_id(*)').eq('user_id', user.id);
                        if (membershipsError) {
                            console.error('Error fetching projects:', membershipsError);
                            setError('حدث خطأ أثناء تحميل المشاريع');
                            return;
                        }
                        if (!membershipsData || membershipsData.length === 0) {
                            setProjects([]);
                            return;
                        }
                        const projectsList = membershipsData.filter({
                            "CreateTask.useEffect.fetchProjects.projectsList": (membership)=>membership.project
                        }["CreateTask.useEffect.fetchProjects.projectsList"]) // Filtrer les projets null
                        .map({
                            "CreateTask.useEffect.fetchProjects.projectsList": (membership)=>({
                                    id: membership.project.id,
                                    name: membership.project.name
                                })
                        }["CreateTask.useEffect.fetchProjects.projectsList"]);
                        setProjects(projectsList);
                        // Si l'utilisateur n'a qu'un seul projet, le sélectionner par défaut
                        if (projectsList.length === 1) {
                            setFormData({
                                "CreateTask.useEffect.fetchProjects": (prev)=>({
                                        ...prev,
                                        projectId: projectsList[0].id
                                    })
                            }["CreateTask.useEffect.fetchProjects"]);
                        }
                    } catch (error) {
                        console.error('Error fetching projects:', error);
                        setError('حدث خطأ أثناء تحميل المشاريع');
                    } finally{
                        setIsLoading(false);
                    }
                }
            }["CreateTask.useEffect.fetchProjects"];
            fetchProjects();
        }
    }["CreateTask.useEffect"], [
        user,
        projectId
    ]);
    // Effet pour charger les membres du projet lorsque projectId change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CreateTask.useEffect": ()=>{
            const fetchProjectMembers = {
                "CreateTask.useEffect.fetchProjectMembers": async ()=>{
                    if (!formData.projectId) {
                        setProjectMembers([]);
                        return;
                    }
                    try {
                        setIsLoading(true);
                        const { data: membersData, error: membersError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('project_members').select('*, user:user_id(*)').eq('project_id', formData.projectId);
                        if (membersError) {
                            console.error('Error fetching project members:', membersError);
                            setError('حدث خطأ أثناء تحميل أعضاء المشروع');
                            return;
                        }
                        if (!membersData || membersData.length === 0) {
                            setProjectMembers([]);
                            return;
                        }
                        const membersList = membersData.filter({
                            "CreateTask.useEffect.fetchProjectMembers.membersList": (membership)=>membership.user
                        }["CreateTask.useEffect.fetchProjectMembers.membersList"]) // Filtrer les utilisateurs null
                        .map({
                            "CreateTask.useEffect.fetchProjectMembers.membersList": (membership)=>({
                                    id: membership.user.id,
                                    full_name: membership.user.full_name,
                                    avatar_url: membership.user.avatar_url,
                                    email: membership.user.email
                                })
                        }["CreateTask.useEffect.fetchProjectMembers.membersList"]);
                        setProjectMembers(membersList);
                    } catch (error) {
                        console.error('Error fetching project members:', error);
                        setError('حدث خطأ أثناء تحميل أعضاء المشروع');
                    } finally{
                        setIsLoading(false);
                    }
                }
            }["CreateTask.useEffect.fetchProjectMembers"];
            fetchProjectMembers();
        }
    }["CreateTask.useEffect"], [
        formData.projectId
    ]);
    // Gérer les changements dans le formulaire
    const handleChange = (e)=>{
        const { name, value } = e.target;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
        // Réinitialiser les messages d'erreur lors de la modification du formulaire
        setError(null);
    };
    // Soumettre le formulaire
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!user) {
            setError('يجب تسجيل الدخول لإنشاء مهمة');
            return;
        }
        if (!formData.projectId) {
            setError('يرجى اختيار مشروع');
            return;
        }
        if (!formData.title.trim()) {
            setError('يرجى إدخال عنوان للمهمة');
            return;
        }
        setIsLoading(true);
        setError(null);
        setSuccessMessage(null);
        try {
            // Préparer les données de la tâche
            const taskData = {
                project_id: formData.projectId,
                title: formData.title.trim(),
                description: formData.description.trim() || null,
                status: formData.status,
                priority: formData.priority,
                due_date: formData.dueDate || null,
                assigned_to: formData.assignedTo || null,
                created_by: user.id,
                completion_percentage: formData.status === 'completed' ? 100 : formData.status === 'not_started' ? 0 : 50
            };
            // Insérer la tâche dans la base de données
            const { data: newTask, error: insertError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('tasks').insert(taskData).select().single();
            if (insertError) {
                console.error('Error creating task:', insertError);
                setError('حدث خطأ أثناء إنشاء المهمة: ' + insertError.message);
                return;
            }
            if (!newTask) {
                setError('حدث خطأ أثناء إنشاء المهمة: لم يتم إرجاع بيانات المهمة');
                return;
            }
            // Afficher un message de succès
            setSuccessMessage('تم إنشاء المهمة بنجاح');
            // Réinitialiser le formulaire
            setFormData({
                title: '',
                description: '',
                status: 'not_started',
                priority: 'medium',
                dueDate: '',
                assignedTo: '',
                projectId: formData.projectId
            });
            // Rediriger vers la page de la tâche après un court délai
            setTimeout(()=>{
                router.push(`/tasks/${newTask.id}`);
            }, 1500);
        } catch (error) {
            console.error('Error creating task:', error);
            setError('حدث خطأ أثناء إنشاء المهمة: ' + (error.message || 'خطأ غير معروف'));
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-lg shadow-md p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold text-gray-800 mb-6",
                children: "إنشاء مهمة جديدة"
            }, void 0, false, {
                fileName: "[project]/src/app/tasks/new/page.tsx",
                lineNumber: 317,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-50 text-red-700 p-4 rounded-lg mb-6",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/tasks/new/page.tsx",
                lineNumber: 320,
                columnNumber: 9
            }, this),
            successMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-green-50 text-green-700 p-4 rounded-lg mb-6",
                children: successMessage
            }, void 0, false, {
                fileName: "[project]/src/app/tasks/new/page.tsx",
                lineNumber: 326,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit,
                className: "space-y-6",
                children: [
                    !projectId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "projectId",
                                className: "block text-sm font-medium text-gray-700 mb-1",
                                children: "المشروع *"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 335,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                id: "projectId",
                                name: "projectId",
                                value: formData.projectId,
                                onChange: handleChange,
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
                                required: true,
                                disabled: isLoading,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "اختر مشروعًا"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 347,
                                        columnNumber: 15
                                    }, this),
                                    projects.map((project)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: project.id,
                                            children: project.name
                                        }, project.id, false, {
                                            fileName: "[project]/src/app/tasks/new/page.tsx",
                                            lineNumber: 349,
                                            columnNumber: 17
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 338,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 334,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "title",
                                className: "block text-sm font-medium text-gray-700 mb-1",
                                children: "عنوان المهمة *"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 359,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                id: "title",
                                name: "title",
                                value: formData.title,
                                onChange: handleChange,
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
                                required: true,
                                disabled: isLoading
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 362,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 358,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "description",
                                className: "block text-sm font-medium text-gray-700 mb-1",
                                children: "وصف المهمة"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 376,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                id: "description",
                                name: "description",
                                value: formData.description,
                                onChange: handleChange,
                                rows: 4,
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
                                disabled: isLoading
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 379,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 375,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "status",
                                className: "block text-sm font-medium text-gray-700 mb-1",
                                children: "حالة المهمة"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 392,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                id: "status",
                                name: "status",
                                value: formData.status,
                                onChange: handleChange,
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
                                disabled: isLoading,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "not_started",
                                        children: "لم تبدأ"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 403,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "in_progress",
                                        children: "قيد التنفيذ"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 404,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "completed",
                                        children: "مكتملة"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 405,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "delayed",
                                        children: "متأخرة"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 406,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 395,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 391,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "priority",
                                className: "block text-sm font-medium text-gray-700 mb-1",
                                children: "أولوية المهمة"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 412,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                id: "priority",
                                name: "priority",
                                value: formData.priority,
                                onChange: handleChange,
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
                                disabled: isLoading,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "low",
                                        children: "منخفضة"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 423,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "medium",
                                        children: "متوسطة"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 424,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "high",
                                        children: "عالية"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 425,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 415,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 411,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "dueDate",
                                className: "block text-sm font-medium text-gray-700 mb-1",
                                children: "تاريخ الاستحقاق"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 431,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "datetime-local",
                                id: "dueDate",
                                name: "dueDate",
                                value: formData.dueDate,
                                onChange: handleChange,
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
                                disabled: isLoading
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 434,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 430,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "assignedTo",
                                className: "block text-sm font-medium text-gray-700 mb-1",
                                children: "تكليف إلى"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 447,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                id: "assignedTo",
                                name: "assignedTo",
                                value: formData.assignedTo,
                                onChange: handleChange,
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
                                disabled: isLoading,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "غير مكلف"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/tasks/new/page.tsx",
                                        lineNumber: 458,
                                        columnNumber: 13
                                    }, this),
                                    projectMembers.map((member)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: member.id,
                                            children: member.full_name
                                        }, member.id, false, {
                                            fileName: "[project]/src/app/tasks/new/page.tsx",
                                            lineNumber: 460,
                                            columnNumber: 15
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 450,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 446,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end space-x-4 space-x-reverse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                                type: "button",
                                onClick: ()=>router.back(),
                                disabled: isLoading,
                                children: "إلغاء"
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 469,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                                type: "submit",
                                primary: true,
                                disabled: isLoading,
                                children: isLoading ? 'جاري الإنشاء...' : 'إنشاء المهمة'
                            }, void 0, false, {
                                fileName: "[project]/src/app/tasks/new/page.tsx",
                                lineNumber: 476,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/tasks/new/page.tsx",
                        lineNumber: 468,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/tasks/new/page.tsx",
                lineNumber: 331,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/tasks/new/page.tsx",
        lineNumber: 316,
        columnNumber: 5
    }, this);
};
_s(CreateTask, "u1hwTo+z4P8sdimx2RL3+ZIAgMA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c1 = CreateTask;
function CreateTaskPage({ params }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto py-8 px-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CreateTask, {
            projectId: params?.projectId
        }, void 0, false, {
            fileName: "[project]/src/app/tasks/new/page.tsx",
            lineNumber: 493,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/tasks/new/page.tsx",
        lineNumber: 492,
        columnNumber: 5
    }, this);
}
_c2 = CreateTaskPage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Button");
__turbopack_context__.k.register(_c1, "CreateTask");
__turbopack_context__.k.register(_c2, "CreateTaskPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_tasks_new_page_tsx_12e0bb6e._.js.map