(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_project_[id]_page_tsx_3d83b9cc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_project_[id]_page_tsx_3d83b9cc._.js",
  "chunks": [
    "static/chunks/node_modules_08c3758a._.js",
    "static/chunks/src_app_project_[id]_page_tsx_9106fc81._.js",
    "static/chunks/node_modules_ae13807f._.js"
  ],
  "source": "dynamic"
});
