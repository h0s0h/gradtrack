(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_profile_page_tsx_c61d05c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_profile_page_tsx_c61d05c3._.js",
  "chunks": [
    "static/chunks/[root of the server]__6f34d023._.js",
    "static/chunks/node_modules_fb90bdc1._.js",
    "static/chunks/src_app_profile_page_tsx_e9387700._.js"
  ],
  "source": "dynamic"
});
