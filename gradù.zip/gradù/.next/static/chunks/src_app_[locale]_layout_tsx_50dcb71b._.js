(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_[locale]_layout_tsx_50dcb71b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_[locale]_layout_tsx_50dcb71b._.js",
  "chunks": [
    "static/chunks/dd92d_modules_next-intl_dist_esm_development_shared_NextIntlClientProvider_18c0091d.js"
  ],
  "source": "dynamic"
});
