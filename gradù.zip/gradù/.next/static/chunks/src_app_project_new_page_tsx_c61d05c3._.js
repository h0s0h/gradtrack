(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_project_new_page_tsx_c61d05c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_project_new_page_tsx_c61d05c3._.js",
  "chunks": [
    "static/chunks/[root of the server]__13c392a2._.js",
    "static/chunks/node_modules_fb90bdc1._.js",
    "static/chunks/src_app_project_new_page_tsx_92a842c0._.js"
  ],
  "source": "dynamic"
});
