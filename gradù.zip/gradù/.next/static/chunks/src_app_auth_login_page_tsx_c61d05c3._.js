(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_auth_login_page_tsx_c61d05c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_auth_login_page_tsx_c61d05c3._.js",
  "chunks": [
    "static/chunks/node_modules_3aa641cb._.js",
    "static/chunks/src_app_auth_login_page_tsx_b1ee8e9f._.js"
  ],
  "source": "dynamic"
});
