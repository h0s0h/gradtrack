(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_dashboard_page_tsx_c61d05c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_dashboard_page_tsx_c61d05c3._.js",
  "chunks": [
    "static/chunks/[root of the server]__0aae7386._.js",
    "static/chunks/src_0efacc7f._.js",
    "static/chunks/node_modules_framer-motion_dist_es_9d1196c1._.js",
    "static/chunks/node_modules_motion-dom_dist_es_7fc0833b._.js",
    "static/chunks/node_modules_lodash_90f72504._.js",
    "static/chunks/node_modules_recharts_es6_9b3940b2._.js",
    "static/chunks/node_modules_ecb15266._.js"
  ],
  "source": "dynamic"
});
