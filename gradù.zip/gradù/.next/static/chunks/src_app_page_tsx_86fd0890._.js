(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_86fd0890._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_86fd0890._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8e0b8417._.js",
    "static/chunks/node_modules_5156a034._.js",
    "static/chunks/src_app_page_tsx_b025fed5._.js"
  ],
  "source": "dynamic"
});
