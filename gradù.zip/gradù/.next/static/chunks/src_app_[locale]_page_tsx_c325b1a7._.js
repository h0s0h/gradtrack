(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_[locale]_page_tsx_c325b1a7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_[locale]_page_tsx_c325b1a7._.js",
  "chunks": [
    "static/chunks/src_app_[locale]_page_tsx_e1a0da29._.js"
  ],
  "source": "dynamic"
});
