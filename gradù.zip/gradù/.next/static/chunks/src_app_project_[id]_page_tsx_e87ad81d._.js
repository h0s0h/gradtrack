(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_project_[id]_page_tsx_e87ad81d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_project_[id]_page_tsx_e87ad81d._.js",
  "chunks": [
    "static/chunks/src_40bf319a._.js",
    "static/chunks/node_modules_a37ef556._.js"
  ],
  "source": "dynamic"
});
