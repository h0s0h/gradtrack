(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_tasks_[id]_page_tsx_c61d05c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_tasks_[id]_page_tsx_c61d05c3._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_38563d53._.js",
    "static/chunks/src_app_tasks_[id]_page_tsx_aaa29562._.js",
    "static/chunks/node_modules_3f174c06._.js"
  ],
  "source": "dynamic"
});
