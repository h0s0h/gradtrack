(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_tasks_new_page_tsx_e87ad81d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_tasks_new_page_tsx_e87ad81d._.js",
  "chunks": [
    "static/chunks/src_app_tasks_new_page_tsx_12e0bb6e._.js"
  ],
  "source": "dynamic"
});
