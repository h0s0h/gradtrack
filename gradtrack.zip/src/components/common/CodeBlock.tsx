// /components/common/CodeBlock.tsx

import React from 'react';
import { Highlight, themes } from 'prism-react-renderer';

// Types pour TypeScript
interface CodeBlockProps {
  code: string;
  language?: string;
  showLineNumbers?: boolean;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ 
  code, 
  language = 'javascript', // Langage par défaut
  showLineNumbers = false 
}) => {
  // Nettoyage du code (suppression des espaces en début/fin)
  const codeString = code.trim();
  
  return (
    <Highlight
      code={codeString}
      language={language as any}
      theme={themes.vsDark}
    >
      {({ className, style, tokens, getLineProps, getTokenProps }) => (
        <pre className={`${className} rounded-md overflow-x-auto p-4`} style={{ ...style, direction: 'ltr' }}>
          {tokens.map((line, i) => (
            <div key={i} {...getLineProps({ line, key: i })}>
              {showLineNumbers && (
                <span className="inline-block w-8 text-right mr-4 text-gray-500 select-none">
                  {i + 1}
                </span>
              )}
              {line.map((token, key) => (
                <span key={key} {...getTokenProps({ token, key })} />
              ))}
            </div>
          ))}
        </pre>
      )}
    </Highlight>
  );
};

export default CodeBlock;