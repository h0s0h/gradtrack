'use client';

import { useState, useEffect, useRef, FormEvent, MouseEvent } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/components/auth/AuthProvider';
import { supabase } from '@/lib/supabase/client';
import { Project, Post, Comment, User, ProjectMember } from '@/lib/supabase/schema';
import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { detectLanguage } from '@/utils/codeUtils';
import CodeBlock from '@/components/common/CodeBlock';
import LanguageSelector from '@/components/common/LanguageSelector';
import PostCard from '@/components/PostCard';

export type PostWithUser = Post & {
  user: User;
  comments: (Comment & { user: User })[];
  views_count: number;
  viewers: User[];
};

export default function ProjectPage() {
  const { id } = useParams();
  const router = useRouter();
  const { user, isLoading } = useAuth();

  // حالات المشروع والمنشورات والأعضاء
  const [project, setProject] = useState<Project | null>(null);
  const [posts, setPosts] = useState<PostWithUser[]>([]);
  const [members, setMembers] = useState<(ProjectMember & { user: User })[]>([]);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [isLoadingProject, setIsLoadingProject] = useState(true);

  // حالات إنشاء المنشور
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostCode, setNewPostCode] = useState('');
  const [newPostCodeLanguage, setNewPostCodeLanguage] = useState('javascript');
  const [showCodeInput, setShowCodeInput] = useState(false);
  const [isSubmittingPost, setIsSubmittingPost] = useState(false);

  // حالات الرسائل والتنبيهات
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // حالات إدارة المشرفين والمودالات الخاصة بهم
  const [showSupervisorMenu, setShowSupervisorMenu] = useState(false);
  const [showAddSupervisorModal, setShowAddSupervisorModal] = useState(false);
  const [showManageSupervisorsModal, setShowManageSupervisorsModal] = useState(false);
  const [isProcessingSupervisor, setIsProcessingSupervisor] = useState(false);
  const supervisorMenuRef = useRef<HTMLDivElement>(null);

  // حالات البحث وإدارة الدعوات في مودال إضافة مشرف
  const [newSupervisorQuery, setNewSupervisorQuery] = useState('');
  const [newSupervisorResults, setNewSupervisorResults] = useState<any[]>([]);
  const [isSearchingSupervisor, setIsSearchingSupervisor] = useState(false);

  // متغير لدالة حركة المودال
  const modalAnimation = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1, transition: { type: "spring", stiffness: 300, damping: 30 } },
    exit: { opacity: 0, scale: 0.9, transition: { duration: 0.2 } }
  };

  // تأثير حركة بسيط
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  // دالة جلب بيانات المشروع والمنشورات والأعضاء
  useEffect(() => {
    const fetchData = async () => {
      if (!user || !id) return;
      try {
        setIsLoadingProject(true);
        setError(null);

        const [projectRes, membersRes, postsRes] = await Promise.all([
          supabase.from('projects').select('*').eq('id', id).single(),
          supabase.from('project_members').select('*, user:user_id(*)').eq('project_id', id),
          supabase.from('posts').select('*, user:user_id(*)').eq('project_id', id).order('created_at', { ascending: false })
        ]);

        if (projectRes.error) throw projectRes.error;
        if (membersRes.error) throw membersRes.error;
        if (postsRes.error) throw postsRes.error;

        const projectData = projectRes.data;
        const membersData = membersRes.data;
        const postsData = postsRes.data;

        // جلب التعليقات والمشاهدات لكل منشور
        const postIds = postsData.map((post: Post) => post.id);
        const [commentsRes, viewsRes] = await Promise.all([
          supabase.from('comments').select('*, user:user_id(*)').in('post_id', postIds).order('created_at', { ascending: true }),
          supabase.from('post_views').select('*, user:user_id(*)').in('post_id', postIds)
        ]);

        if (commentsRes.error) throw commentsRes.error;
        if (viewsRes.error) throw viewsRes.error;

        const commentsByPostId = commentsRes.data.reduce((acc: Record<string, any>, comment: any) => {
          acc[comment.post_id] = acc[comment.post_id] || [];
          acc[comment.post_id].push(comment);
          return acc;
        }, {});

        const viewsByPostId = viewsRes.data.reduce((acc: Record<string, any>, view: any) => {
          acc[view.post_id] = acc[view.post_id] || [];
          acc[view.post_id].push(view);
          return acc;
        }, {});

        if (postIds.length > 0) {
          const viewsToInsert = postIds.map((postId: any) => ({
            post_id: postId,
            user_id: user.id
          }));
          const { error: recordViewError } = await supabase
            .from('post_views')
            .upsert(viewsToInsert, { onConflict: 'post_id,user_id' });
          if (recordViewError) console.error('Error recording views:', recordViewError);
        }

        const postsWithComments = postsData.map((post: any) => {
          const postComments = commentsByPostId[post.id] || [];
          const postViews = viewsByPostId[post.id] || [];
          return {
            ...post,
            comments: postComments,
            views_count: postViews.length,
            viewers: postViews.map((view: any) => view.user)
          };
        });

        const userMember = membersData.find((member: any) => member.user_id === user.id);
        setUserRole(userMember?.role || null);

        setProject(projectData);
        setMembers(membersData);
        setPosts(postsWithComments);
      } catch (err) {
        console.error('Error fetching project data:', err);
        setError('حدث خطأ أثناء جلب بيانات المشروع');
      } finally {
        setIsLoadingProject(false);
      }
    };

    fetchData();
  }, [id, user]);

  // تنسيق التاريخ باللغة العربية
  const formatDate = (dateString: string) =>
    format(new Date(dateString), 'dd MMM yyyy - HH:mm', { locale: arSA });

  // التعامل مع النقر خارج قائمة المشرفين لإغلاقها
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (showSupervisorMenu && supervisorMenuRef.current && !supervisorMenuRef.current.contains(event.target as Node)) {
        setShowSupervisorMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showSupervisorMenu]);

  // إنشاء منشور جديد
  const handleSubmitPost = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !project || !newPostContent.trim()) return;
    try {
      setIsSubmittingPost(true);
      setError(null);
      const codeLanguage = newPostCode ? (newPostCodeLanguage || detectLanguage(newPostCode)) : null;
      const { data: newPost, error: postError } = await supabase
        .from('posts')
        .insert({
          project_id: project.id,
          user_id: user.id,
          content: newPostContent,
          code_snippet: newPostCode || null,
          code_language: codeLanguage
        })
        .select('*, user:user_id(*)')
        .single();
      if (postError) throw postError;
      setPosts([{ ...newPost, comments: [], views_count: 0, viewers: [] }, ...posts]);
      setSuccessMessage('تم نشر التحديث بنجاح');
      setTimeout(() => setSuccessMessage(null), 3000);
      setNewPostContent('');
      setNewPostCode('');
      setNewPostCodeLanguage('javascript');
      setShowCodeInput(false);
    } catch (err) {
      console.error('Error creating post:', err);
      setError('حدث خطأ أثناء إنشاء المنشور');
    } finally {
      setIsSubmittingPost(false);
    }
  };

  // تحديث وحذف المنشورات والتعليقات (وظائف مشابهة كما في الكود الأصلي)
  const handleUpdatePost = async (updatedPost: PostWithUser) => {
    try {
      const { error: updateError } = await supabase
        .from('posts')
        .update({
          content: updatedPost.content,
          code_snippet: updatedPost.code_snippet,
          code_language: updatedPost.code_language,
          updated_at: new Date().toISOString()
        })
        .eq('id', updatedPost.id);
      if (updateError) throw updateError;
      setPosts(posts.map(post => post.id === updatedPost.id ? updatedPost : post));
      setSuccessMessage('تم تحديث المنشور بنجاح');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      console.error('Error updating post:', err);
      setError('حدث خطأ أثناء تحديث المنشور');
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنشور؟')) return;
    try {
      const { error: deleteError } = await supabase
        .from('posts')
        .delete()
        .eq('id', postId);
      if (deleteError) throw deleteError;
      setPosts(posts.filter(post => post.id !== postId));
      setSuccessMessage('تم حذف المنشور بنجاح');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      console.error('Error deleting post:', err);
      setError('حدث خطأ أثناء حذف المنشور');
    }
  };

  const handleSubmitComment = async (
    postId: string,
    content: string,
    codeSnippet: string = '',
    codeLanguage: string = ''
  ) => {
    if (!user || !content.trim()) return;
    try {
      const finalCodeLanguage = codeSnippet ? (codeLanguage || detectLanguage(codeSnippet)) : null;
      const { data: newComment, error: commentError } = await supabase
        .from('comments')
        .insert({
          post_id: postId,
          user_id: user.id,
          content,
          code_snippet: codeSnippet || null,
          code_language: finalCodeLanguage
        })
        .select('*, user:user_id(*)')
        .single();
      if (commentError) throw commentError;
      setPosts(posts.map(post => {
        if (post.id === postId) {
          return { ...post, comments: [...post.comments, newComment] };
        }
        return post;
      }));
    } catch (err) {
      console.error('Error creating comment:', err);
      setError('حدث خطأ أثناء إنشاء التعليق');
    }
  };

  const handleDeleteComment = async (postId: string, commentId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا التعليق؟')) return;
    try {
      const { error: deleteError } = await supabase
        .from('comments')
        .delete()
        .eq('id', commentId);
      if (deleteError) throw deleteError;
      setPosts(posts.map(post => {
        if (post.id === postId) {
          return { ...post, comments: post.comments.filter(comment => comment.id !== commentId) };
        }
        return post;
      }));
    } catch (err) {
      console.error('Error deleting comment:', err);
      setError('حدث خطأ أثناء حذف التعليق');
    }
  };

  // دوال إدارة صلاحيات المشرفين
  const handleRemoveSupervisor = async (memberId: string) => {
    if (!confirm('هل أنت متأكد من إلغاء صلاحية المشرف لهذا العضو؟')) return;
    try {
      setIsProcessingSupervisor(true);
      const { error } = await supabase
        .from('project_members')
        .update({ role: 'member' })
        .eq('id', memberId);
      if (error) throw error;
      setMembers(members.map(m => m.id === memberId ? { ...m, role: 'member' } : m));
      setSuccessMessage('تم إلغاء صلاحية المشرف');
      setTimeout(() => setSuccessMessage(null), 3000);
      setShowManageSupervisorsModal(false);
    } catch (err) {
      console.error('Error demoting supervisor:', err);
      setError('حدث خطأ أثناء إلغاء صلاحية المشرف');
    } finally {
      setIsProcessingSupervisor(false);
    }
  };

  // دالة إرسال الدعوة إذا لم يكن المستخدم موجوداً (يمكنك تعديلها بما يتناسب مع منطق تطبيقك)
  const generateUniqueInviteCode = () => {
    const timestamp = new Date().getTime().toString(36);
    const randomStr = Math.random().toString(36).substring(2, 10);
    return `${timestamp}-${randomStr}`;
  };

  const sendInvitation = async (email: string, projectId: string, role: string = 'supervisor') => {
    try {
      const code = generateUniqueInviteCode();
      const { data: existingInvites, error: checkError } = await supabase
        .from('project_invitations')
        .select('id')
        .eq('project_id', projectId)
        .eq('email', email);
      
      if (checkError) throw checkError;
      
      if (existingInvites && existingInvites.length > 0) {
        const { error: updateError } = await supabase
          .from('project_invitations')
          .update({ 
            role, 
            invite_code: code, 
            invited_by: user.id,
            accepted: false,
            expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
          })
          .eq('id', existingInvites[0].id);
        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('project_invitations')
          .insert({ 
            project_id: projectId, 
            email, 
            role, 
            invite_code: code, 
            invited_by: user.id 
          });
        if (insertError) throw insertError;
      }
      
      return true;
    } catch (error) {
      console.error('Error sending invitation:', error);
      return false;
    }
  };

  // دوال البحث لإضافة مشرف جديد
  const searchSupervisor = async (query: string) => {
    setNewSupervisorQuery(query);
    if (!query.trim() || query.length < 2) {
      setNewSupervisorResults([]);
      return;
    }
    try {
      setIsSearchingSupervisor(true);
      // البحث في جدول "users" باستخدام تطابق على البريد أو الاسم
      const { data, error } = await supabase
        .from('users')
        .select('id, email, full_name, avatar_url')
        .or(`email.ilike.%${query}%,full_name.ilike.%${query}%`)
        .limit(5);
      if (error) throw error;
      let results = data || [];
      // إذا كان الإدخال بريد إلكتروني صحيح ولا توجد نتائج؛ نضيف نتيجة دعوة
      const isEmail = /^\S+@\S+\.\S+$/.test(query.trim());
      if (isEmail && results.length === 0) {
        results = [{ id: 'invite', email: query.trim(), full_name: query.trim(), isInvitation: true }];
      }
      setNewSupervisorResults(results);
    } catch (err) {
      console.error('خطأ أثناء البحث عن المشرفين:', err);
      setNewSupervisorResults([]);
    } finally {
      setIsSearchingSupervisor(false);
    }
  };

  // دالة عند اختيار مستخدم من نتائج البحث
  const handleSelectSupervisor = async (selectedUser: any) => {
    try {
      setIsProcessingSupervisor(true);
      if (selectedUser.isInvitation) {
        // إذا كانت نتيجة الدعوة يتم إرسال الدعوة
        const inviteResult = await sendInvitation(selectedUser.email, project!.id, 'supervisor');
        if (inviteResult) {
          setSuccessMessage(`تم إرسال دعوة للمستخدم ${selectedUser.email}`);
        } else {
          setError('حدث خطأ أثناء إرسال الدعوة');
        }
      } else {
        // تحقق إذا كان المستخدم موجوداً بالفعل في المشروع
        const existingMember = members.find((m) => m.user.id === selectedUser.id);
        if (existingMember) {
          if (existingMember.role === 'member') {
            const { error } = await supabase
              .from('project_members')
              .update({ role: 'supervisor' })
              .eq('id', existingMember.id);
            if (error) throw error;
            setMembers(members.map(m => m.id === existingMember.id ? { ...m, role: 'supervisor' } : m));
            setSuccessMessage('تم ترقية العضو إلى مشرف');
          } else {
            setError('هذا المستخدم بالفعل مشرف');
          }
        } else {
          // إذا لم يكن موجوداً يتم إضافته كمشرف جديد
          const { data, error } = await supabase
            .from('project_members')
            .insert({
              project_id: project!.id,
              user_id: selectedUser.id,
              role: 'supervisor'
            })
            .select()
            .single();
          if (error) throw error;
          setMembers([...members, { ...data, user: selectedUser }]);
          setSuccessMessage('تم إضافة المشرف بنجاح');
        }
      }
      setTimeout(() => setSuccessMessage(null), 3000);
      setNewSupervisorQuery("");
      setNewSupervisorResults([]);
      setShowAddSupervisorModal(false);
    } catch (err) {
      console.error('خطأ أثناء إضافة المشرف:', err);
      setError('حدث خطأ أثناء إضافة المشرف');
    } finally {
      setIsProcessingSupervisor(false);
    }
  };

  // حالات التحميل وتحقق تسجيل الدخول
  if (isLoading || isLoadingProject) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500 mb-4"></div>
          <p className="text-gray-600">جاري تحميل بيانات المشروع...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-md w-full">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-indigo-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m0 0v2m0-2h2m-2 0H9m3-6V7m0 0V5m0 2h2m-2 0H9M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          <h2 className="text-2xl font-bold mb-4">يجب تسجيل الدخول للوصول إلى صفحة المشروع</h2>
          <Link href="/auth/login" className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition block w-full text-center">
            تسجيل الدخول
          </Link>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-md w-full">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-red-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <h2 className="text-2xl font-bold mb-4">المشروع غير موجود أو ليس لديك صلاحية الوصول إليه</h2>
          <Link href="/dashboard" className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition block w-full text-center">
            العودة إلى لوحة التحكم
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* الهيدر */}
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard" className="text-indigo-600 hover:text-indigo-800 ml-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
            </Link>
            <h1 className="text-2xl font-bold text-gray-800">{project.name}</h1>
          </div>
         
        </div>
      </header>

      {/* المحتوى الرئيسي */}
      <main className="container mx-auto px-4 py-8 pb-20">
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: -20 }}
              className="bg-red-50 text-red-700 p-4 rounded-md mb-6 flex justify-between items-center"
            >
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {error}
              </div>
              <button onClick={() => setError(null)} className="text-red-700 hover:text-red-900">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </motion.div>
          )}

          {successMessage && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: -20 }}
              className="bg-green-50 text-green-700 p-4 rounded-md mb-6 flex justify-between items-center"
            >
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                {successMessage}
              </div>
              <button onClick={() => setSuccessMessage(null)} className="text-green-700 hover:text-green-900">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* منطقة المنشورات */}
          <div className="lg:col-span-3">
            <motion.div initial="hidden" animate="visible" variants={fadeIn} className="mb-8">
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-xl font-bold mb-4 flex items-center text-blue-700">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  نشر تحديث جديد
                </h2>
                <form onSubmit={handleSubmitPost}>
                  <div className="mb-4">
                    <label htmlFor="content" className="block text-sm font-medium text-gray-800 mb-1">المحتوى</label>
                    <textarea
                      id="content"
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-400 rounded-md text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 transition"
                      placeholder="اكتب تحديثك هنا..."
                      value={newPostContent}
                      onChange={(e) => setNewPostContent(e.target.value)}
                      required
                      dir="rtl"
                    />
                  </div>
                  <div className="mb-4">
                    <button
                      type="button"
                      onClick={() => setShowCodeInput(!showCodeInput)}
                      className="text-sm text-indigo-600 hover:text-indigo-800 transition flex items-center"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                      </svg>
                      {showCodeInput ? 'إخفاء الكود' : 'إضافة كود'}
                    </button>
                  </div>
                  {showCodeInput && (
                    <>
                      <div className="mb-2">
                        <LanguageSelector
                          selectedLanguage={newPostCodeLanguage}
                          onLanguageChange={setNewPostCodeLanguage}
                        />
                      </div>
                      <div className="mb-4">
                        <textarea
                          id="code"
                          rows={4}
                          className="w-full px-3 py-2 border border-gray-400 rounded-md font-mono text-sm bg-gray-50 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 transition"
                          placeholder="// أضف الكود هنا"
                          value={newPostCode}
                          onChange={(e) => setNewPostCode(e.target.value)}
                          dir="ltr"
                        />
                      </div>
                      {newPostCode && (
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-800 mb-1">معاينة الكود</label>
                          <CodeBlock
                            code={newPostCode}
                            language={newPostCodeLanguage || detectLanguage(newPostCode)}
                            showLineNumbers={true}
                          />
                        </div>
                      )}
                    </>
                  )}
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={isSubmittingPost || !newPostContent.trim()}
                      className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition disabled:opacity-70 flex items-center"
                    >
                      {isSubmittingPost ? (
                        <>
                          <svg className="animate-spin h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          جاري النشر...
                        </>
                      ) : (
                        <>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                          </svg>
                          نشر التحديث
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
              <h2 className="text-xl font-bold mb-4 flex items-center text-blue-700">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                </svg>
                التحديثات
              </h2>
              <AnimatePresence>
                {posts.length === 0 ? (
                  <motion.div initial="hidden" animate="visible" variants={fadeIn} className="bg-white rounded-lg shadow-md p-6 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                    </svg>
                    <p className="text-gray-600">لا توجد تحديثات بعد</p>
                    <p className="text-gray-500 text-sm mt-2">كن أول من ينشر تحديثًا في هذا المشروع!</p>
                  </motion.div>
                ) : (
                  <div className="space-y-6">
                    {posts.map((post, index) => (
                      <PostCard
                        key={post.id}
                        post={post}
                        currentUser={user}
                        userRole={userRole}
                        onSubmitComment={handleSubmitComment}
                        onDeleteComment={handleDeleteComment}
                        onUpdatePost={handleUpdatePost}
                        onDeletePost={handleDeletePost}
                        animationDelay={index * 0.1}
                        formatDate={formatDate}
                      />
                    ))}
                  </div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          {/* الشريط الجانبي */}
          <div className="lg:col-span-1">
            <div className="lg:sticky lg:top-24">
              <motion.div initial="hidden" animate="visible" variants={fadeIn}>
                <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                  <h3 className="text-lg font-bold mb-3 flex items-center text-blue-700">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    عن المشروع
                  </h3>
                  <p className="text-gray-600 mb-4">{project.description || 'لا يوجد وصف'}</p>
                  <div className="text-sm text-gray-500 divide-y divide-gray-100">
                    <div className="py-2 flex justify-between">
                      <span>تاريخ الإنشاء:</span>
                      <span>{formatDate(project.created_at)}</span>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span>آخر تحديث:</span>
                      <span>{formatDate(project.updated_at)}</span>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span>عدد المنشورات:</span>
                      <span>{posts.length}</span>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span>عدد التعليقات:</span>
                      <span>{posts.reduce((total, post) => total + post.comments.length, 0)}</span>
                    </div>
                  </div>
                </div>

                {/* قائمة الأعضاء والمشرفين */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="text-lg font-bold flex items-center text-blue-700">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                      </svg>
                      أعضاء المشروع
                    </h3>
                    {userRole === 'owner' && (
                      <div className="relative" ref={supervisorMenuRef}>
                        <button onClick={() => setShowSupervisorMenu(!showSupervisorMenu)} className="p-2 hover:bg-gray-100 rounded-full" aria-label="إدارة المشرفين">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 6a2 2 0 110-4 2 2 0 010 4zm0 6a2 2 0 110-4 2 2 0 010 4zm0 6a2 2 0 110-4 2 2 0 010 4z" />
                          </svg>
                        </button>
                        {showSupervisorMenu && (
                          <div className="absolute mt-2 w-48 bg-white rounded-md shadow-lg z-20 -left-32">
                            <div className="py-1">
                              <button
                                className="block w-full text-right px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                onClick={() => {
                                  setShowAddSupervisorModal(true);
                                  setShowSupervisorMenu(false);
                                }}
                              >
                                إضافة مشرف جديد
                              </button>
                              <button
                                className="block w-full text-right px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                onClick={() => {
                                  setShowManageSupervisorsModal(true);
                                  setShowSupervisorMenu(false);
                                }}
                              >
                                إدارة المشرفين الحاليين
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="space-y-3">
                    {members.length === 0 ? (
                      <p className="text-gray-500 text-center py-2">لا يوجد أعضاء بعد</p>
                    ) : (
                      members.map(member => (
                        <div key={member.id} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center ml-2">
                              {member.user.avatar_url ? (
                                <img src={member.user.avatar_url} alt={member.user.full_name} className="w-8 h-8 rounded-full" />
                              ) : (
                                <span className="text-indigo-600 font-semibold">{member.user.full_name?.charAt(0) || member.user.email.charAt(0)}</span>
                              )}
                            </div>
                            <div>
                              <p className="text-gray-800 font-medium">{member.user.full_name || member.user.email}</p>
                              <div className="flex items-center gap-2">
                                <div className="w-2 h-2 bg-indigo-600 rounded-full"></div>
                                <p className="text-xs text-gray-500 flex items-center">
                                  {member.role === 'owner' ? 'مالك' : member.role === 'supervisor' ? 'مشرف' : 'عضو'}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </main>

      {/* مودال إضافة مشرف جديد مع دعم البحث والدعوة */}
      <AnimatePresence>
        {showAddSupervisorModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div
              initial="hidden"
              animate="visible"
              exit="exit"
              variants={modalAnimation}
              className="bg-white rounded-lg shadow-xl max-w-md w-full p-6"
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900">إضافة مشرف جديد</h3>
                <button
                  onClick={() => {
                    setShowAddSupervisorModal(false);
                    setNewSupervisorQuery("");
                    setNewSupervisorResults([]);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              {/* حقل البحث لإضافة مشرف */}
              <div className="mb-4">
                <label htmlFor="supervisor-search" className="block text-sm font-medium text-gray-800 mb-1">
                  ابحث عن مستخدم لإضافته كمشرف
                </label>
                <input
                  id="supervisor-search"
                  type="text"
                  placeholder="أدخل الاسم أو البريد"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  value={newSupervisorQuery}
                  onChange={(e) => searchSupervisor(e.target.value)}
                />
                {isSearchingSupervisor && (
                  <div className="absolute right-3 top-3">
                    <svg className="animate-spin h-4 w-4 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                )}
              </div>
              {/* قائمة نتائج البحث */}
              {newSupervisorResults.length > 0 && (
                <div className="mb-4 max-h-60 overflow-y-auto border border-gray-200 rounded-md">
                  <ul>
                    {newSupervisorResults.map((u) => (
                      <li
                        key={u.id}
                        className="px-3 py-2 cursor-pointer hover:bg-gray-100 flex items-center"
                        onClick={() => handleSelectSupervisor(u)}
                      >
                        <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center mr-2">
                          {u.avatar_url ? (
                            <img src={u.avatar_url} alt={u.full_name} className="w-8 h-8 rounded-full" />
                          ) : (
                            <span className="text-indigo-600 font-semibold">{(u.full_name || u.email).charAt(0)}</span>
                          )}
                        </div>
                        <div>
                          <p className="text-gray-800">{u.isInvitation ? `دعوة: ${u.email}` : (u.full_name || u.email)}</p>
                          {!u.isInvitation && <p className="text-xs text-gray-500">{u.email}</p>}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <div className="flex justify-end">
                <button
                  onClick={() => {
                    setShowAddSupervisorModal(false);
                    setNewSupervisorQuery("");
                    setNewSupervisorResults([]);
                  }}
                  className="bg-gray-200 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-300 transition"
                >
                  إغلاق
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* مودال إدارة المشرفين الحاليين */}
      <AnimatePresence>
        {showManageSupervisorsModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div initial="hidden" animate="visible" exit="exit" variants={modalAnimation} className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900">إدارة المشرفين</h3>
                <button onClick={() => setShowManageSupervisorsModal(false)} className="text-gray-400 hover:text-gray-600">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="mb-4">
                <p className="text-gray-600 mb-2">المشرفون الحاليون:</p>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {members.filter(member => member.role === 'supervisor').map(member => (
                    <div key={member.id} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-md">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center ml-2">
                          {member.user.avatar_url ? (
                            <img src={member.user.avatar_url} alt={member.user.full_name} className="w-8 h-8 rounded-full" />
                          ) : (
                            <span className="text-indigo-600 font-semibold">{member.user.full_name?.charAt(0) || member.user.email.charAt(0)}</span>
                          )}
                        </div>
                        <span className="text-gray-800">{member.user.full_name || member.user.email}</span>
                      </div>
                      <button
                        onClick={() => handleRemoveSupervisor(member.id)}
                        disabled={isProcessingSupervisor}
                        className="bg-red-600 text-white px-3 py-1 rounded-md hover:bg-red-700 transition disabled:opacity-70 text-sm"
                      >
                        {isProcessingSupervisor ? 'جاري...' : 'إلغاء'}
                      </button>
                    </div>
                  ))}
                  {members.filter(member => member.role === 'supervisor').length === 0 && (
                    <p className="text-gray-500 text-center py-4">لا يوجد مشرفون حاليًا</p>
                  )}
                </div>
              </div>
              <div className="flex justify-end">
                <button onClick={() => setShowManageSupervisorsModal(false)} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-300 transition">
                  إغلاق
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
