-- GradTrack Database Schema - Fixed Version with Recursion Issue Resolved

-- Create extensions if not already created
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create custom types
CREATE TYPE user_role AS ENUM ('student', 'supervisor', 'admin');
CREATE TYPE member_role AS ENUM ('owner', 'supervisor', 'member');
CREATE TYPE notification_type AS ENUM ('post_created', 'comment_added', 'project_invitation', 'inactivity_alert', 'invitation_accepted');

-- Create Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    avatar_url TEXT,
    role user_role NOT NULL DEFAULT 'student',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create Projects table
CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create Project Members table (many-to-many relationship)
CREATE TABLE project_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role member_role NOT NULL DEFAULT 'member',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    UNIQUE(project_id, user_id)
);

-- Create Posts table
CREATE TABLE posts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    code_snippet TEXT,
    image_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create Post Views table
CREATE TABLE post_views (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    viewed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    UNIQUE(post_id, user_id)
);

-- Create Comments table
CREATE TABLE comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    code_snippet TEXT,
    image_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create Notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    type notification_type NOT NULL,
    related_id UUID,
    is_read BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create Project Invitations table
CREATE TABLE project_invitations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    role member_role NOT NULL DEFAULT 'member',
    invite_code TEXT NOT NULL,
    invited_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    accepted BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '7 days') NOT NULL,
    UNIQUE(project_id, email)
);

-- Create indexes for better performance
CREATE INDEX idx_projects_owner_id ON projects(owner_id);
CREATE INDEX idx_project_members_project_id ON project_members(project_id);
CREATE INDEX idx_project_members_user_id ON project_members(user_id);
CREATE INDEX idx_posts_project_id ON posts(project_id);
CREATE INDEX idx_posts_user_id ON posts(user_id);
CREATE INDEX idx_post_views_post_id ON post_views(post_id);
CREATE INDEX idx_post_views_user_id ON post_views(user_id);
CREATE INDEX idx_comments_post_id ON comments(post_id);
CREATE INDEX idx_comments_user_id ON comments(user_id);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_type ON notifications(type);
CREATE INDEX idx_project_invitations_project_id ON project_invitations(project_id);
CREATE INDEX idx_project_invitations_email ON project_invitations(email);
CREATE INDEX idx_project_invitations_invite_code ON project_invitations(invite_code);

-- Create a function to automatically update 'updated_at' fields
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply the trigger to tables with updated_at column
CREATE TRIGGER update_projects_updated_at
BEFORE UPDATE ON projects
FOR EACH ROW EXECUTE FUNCTION update_modified_column();

CREATE TRIGGER update_posts_updated_at
BEFORE UPDATE ON posts
FOR EACH ROW EXECUTE FUNCTION update_modified_column();

CREATE TRIGGER update_comments_updated_at
BEFORE UPDATE ON comments
FOR EACH ROW EXECUTE FUNCTION update_modified_column();

-- FIXED: current_user_id() function to correctly get current user
CREATE OR REPLACE FUNCTION current_user_id() 
RETURNS UUID AS $$
BEGIN
    -- In production with Supabase Auth:
    RETURN (auth.uid());
    
    -- If not using Supabase, replace with your authentication system's method
    -- Example with a session variable:
    -- RETURN current_setting('app.current_user_id')::UUID;
    
    -- IMPORTANT: For development/testing only (uncomment only one):
    -- RETURN NULL; -- Disable RLS checks
    -- RETURN '00000000-0000-0000-0000-000000000000'::UUID; -- Test with specific ID
EXCEPTION
    WHEN OTHERS THEN
        -- Fallback for development/test environments
        RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- FIXED: Function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
    -- Check if user_uuid is NULL (system access)
    IF user_uuid IS NULL THEN
        RETURN TRUE;
    END IF;
    
    RETURN EXISTS (
        SELECT 1 FROM users
        WHERE id = user_uuid AND role = 'admin'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- FIXED: Helper functions for permissions with recursion issue resolved
-- Create a view to avoid RLS recursion when checking project membership
CREATE OR REPLACE VIEW project_members_direct AS
SELECT * FROM project_members;

-- FIXED: is_project_member function that uses the view instead of the table
CREATE OR REPLACE FUNCTION is_project_member(project_uuid UUID, user_uuid UUID) 
RETURNS BOOLEAN AS $$
BEGIN
    -- Check if user_uuid is NULL (which means system or admin access)
    IF user_uuid IS NULL THEN
        RETURN TRUE;
    END IF;

    -- Check if the user is an admin
    IF EXISTS (SELECT 1 FROM users WHERE id = user_uuid AND role = 'admin') THEN
        RETURN TRUE;
    END IF;

    -- Use the view instead of the table to avoid RLS recursion
    RETURN EXISTS (
        SELECT 1 FROM project_members_direct 
        WHERE project_id = project_uuid AND user_id = user_uuid
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- FIXED: can_manage_project function that uses the view instead of the table
CREATE OR REPLACE FUNCTION can_manage_project(project_uuid UUID, user_uuid UUID) 
RETURNS BOOLEAN AS $$
BEGIN
    -- Check if user_uuid is NULL (which means system or admin access)
    IF user_uuid IS NULL THEN
        RETURN TRUE;
    END IF;

    -- Check if the user is an admin
    IF EXISTS (SELECT 1 FROM users WHERE id = user_uuid AND role = 'admin') THEN
        RETURN TRUE;
    END IF;

    -- Check if the user is the project owner
    IF EXISTS (SELECT 1 FROM projects WHERE id = project_uuid AND owner_id = user_uuid) THEN
        RETURN TRUE;
    END IF;

    -- Use the view instead of the table to avoid RLS recursion
    RETURN EXISTS (
        SELECT 1 FROM project_members_direct 
        WHERE project_id = project_uuid 
        AND user_id = user_uuid 
        AND role IN ('owner', 'supervisor')
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- FIXED: Enable Row Level Security (RLS) on all tables with improved policies

-- Projects table RLS
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

-- FIXED: Projects policies
DROP POLICY IF EXISTS projects_visibility ON projects;
DROP POLICY IF EXISTS projects_insert ON projects;
DROP POLICY IF EXISTS projects_update ON projects;
DROP POLICY IF EXISTS projects_delete ON projects;

CREATE POLICY projects_visibility ON projects
    FOR SELECT
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        owner_id = current_user_id() OR 
        is_project_member(id, current_user_id())
    );

CREATE POLICY projects_insert ON projects
    FOR INSERT
    WITH CHECK (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        owner_id = current_user_id()
    );

CREATE POLICY projects_update ON projects
    FOR UPDATE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        owner_id = current_user_id() OR 
        can_manage_project(id, current_user_id())
    );

CREATE POLICY projects_delete ON projects
    FOR DELETE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        owner_id = current_user_id()
    );

-- Project Members table RLS
ALTER TABLE project_members ENABLE ROW LEVEL SECURITY;

-- FIXED: Project Members policies with recursion issue resolved
DROP POLICY IF EXISTS project_members_visibility ON project_members;
DROP POLICY IF EXISTS project_members_insert ON project_members;
DROP POLICY IF EXISTS project_members_update ON project_members;
DROP POLICY IF EXISTS project_members_delete ON project_members;

-- FIXED: This policy now avoids the recursive reference to project_members
CREATE POLICY project_members_visibility ON project_members
    FOR SELECT
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id() OR 
        EXISTS (
            SELECT 1 FROM projects p
            WHERE p.id = project_id AND (
                p.owner_id = current_user_id() OR
                EXISTS (
                    SELECT 1 FROM project_members_direct pm
                    WHERE pm.project_id = p.id AND pm.user_id = current_user_id()
                )
            )
        )
    );

CREATE POLICY project_members_insert ON project_members
    FOR INSERT
    WITH CHECK (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        can_manage_project(project_id, current_user_id())
    );

CREATE POLICY project_members_update ON project_members
    FOR UPDATE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        can_manage_project(project_id, current_user_id())
    );

CREATE POLICY project_members_delete ON project_members
    FOR DELETE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        can_manage_project(project_id, current_user_id())
    );

-- Posts table RLS
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

-- FIXED: Posts policies
DROP POLICY IF EXISTS posts_visibility ON posts;
DROP POLICY IF EXISTS posts_insert ON posts;
DROP POLICY IF EXISTS posts_update ON posts;
DROP POLICY IF EXISTS posts_delete ON posts;

CREATE POLICY posts_visibility ON posts
    FOR SELECT
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id() OR 
        is_project_member(project_id, current_user_id())
    );

CREATE POLICY posts_insert ON posts
    FOR INSERT
    WITH CHECK (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        (user_id = current_user_id() AND
        is_project_member(project_id, current_user_id()))
    );

CREATE POLICY posts_update ON posts
    FOR UPDATE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id() OR 
        can_manage_project(project_id, current_user_id())
    );

CREATE POLICY posts_delete ON posts
    FOR DELETE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id() OR 
        can_manage_project(project_id, current_user_id())
    );

-- Post Views table RLS
ALTER TABLE post_views ENABLE ROW LEVEL SECURITY;

-- FIXED: Post Views policies
DROP POLICY IF EXISTS post_views_visibility ON post_views;
DROP POLICY IF EXISTS post_views_insert ON post_views;

CREATE POLICY post_views_visibility ON post_views
    FOR SELECT
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id() OR 
        EXISTS (
            SELECT 1 FROM posts p
            WHERE p.id = post_id AND is_project_member(p.project_id, current_user_id())
        )
    );

CREATE POLICY post_views_insert ON post_views
    FOR INSERT
    WITH CHECK (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        (user_id = current_user_id() AND
        EXISTS (
            SELECT 1 FROM posts p
            WHERE p.id = post_id AND is_project_member(p.project_id, current_user_id())
        ))
    );

-- Comments table RLS
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

-- FIXED: Comments policies
DROP POLICY IF EXISTS comments_visibility ON comments;
DROP POLICY IF EXISTS comments_insert ON comments;
DROP POLICY IF EXISTS comments_update ON comments;
DROP POLICY IF EXISTS comments_delete ON comments;

CREATE POLICY comments_visibility ON comments
    FOR SELECT
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id() OR 
        EXISTS (
            SELECT 1 FROM posts p
            WHERE p.id = post_id AND is_project_member(p.project_id, current_user_id())
        )
    );

CREATE POLICY comments_insert ON comments
    FOR INSERT
    WITH CHECK (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        (user_id = current_user_id() AND
        EXISTS (
            SELECT 1 FROM posts p
            WHERE p.id = post_id AND is_project_member(p.project_id, current_user_id())
        ))
    );

CREATE POLICY comments_update ON comments
    FOR UPDATE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id()
    );

CREATE POLICY comments_delete ON comments
    FOR DELETE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id() OR 
        EXISTS (
            SELECT 1 FROM posts p
            WHERE p.id = post_id AND can_manage_project(p.project_id, current_user_id())
        )
    );

-- Notifications table RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- FIXED: Notifications policies
DROP POLICY IF EXISTS notifications_visibility ON notifications;
DROP POLICY IF EXISTS notifications_update ON notifications;

CREATE POLICY notifications_visibility ON notifications
    FOR SELECT
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id()
    );

CREATE POLICY notifications_update ON notifications
    FOR UPDATE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        user_id = current_user_id()
    );

-- Project Invitations table RLS
ALTER TABLE project_invitations ENABLE ROW LEVEL SECURITY;

-- FIXED: Project Invitations policies
DROP POLICY IF EXISTS project_invitations_visibility ON project_invitations;
DROP POLICY IF EXISTS project_invitations_insert ON project_invitations;
DROP POLICY IF EXISTS project_invitations_update ON project_invitations;
DROP POLICY IF EXISTS project_invitations_delete ON project_invitations;

CREATE POLICY project_invitations_visibility ON project_invitations
    FOR SELECT
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        invited_by = current_user_id() OR 
        email = (SELECT email FROM users WHERE id = current_user_id()) OR
        can_manage_project(project_id, current_user_id())
    );

CREATE POLICY project_invitations_insert ON project_invitations
    FOR INSERT
    WITH CHECK (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        (invited_by = current_user_id() AND
        can_manage_project(project_id, current_user_id()))
    );

CREATE POLICY project_invitations_update ON project_invitations
    FOR UPDATE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        invited_by = current_user_id() OR
        email = (SELECT email FROM users WHERE id = current_user_id()) OR
        can_manage_project(project_id, current_user_id())
    );

CREATE POLICY project_invitations_delete ON project_invitations
    FOR DELETE
    USING (
        current_user_id() IS NULL OR
        is_admin(current_user_id()) OR
        invited_by = current_user_id() OR
        can_manage_project(project_id, current_user_id())
    );

-- Add triggers for automation

-- Add project owner as a member automatically
CREATE OR REPLACE FUNCTION add_owner_as_project_member()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO project_members (project_id, user_id, role)
    VALUES (NEW.id, NEW.owner_id, 'owner');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_add_owner_as_project_member
AFTER INSERT ON projects
FOR EACH ROW EXECUTE FUNCTION add_owner_as_project_member();

-- Create notification when a post is created
CREATE OR REPLACE FUNCTION notify_on_post_creation()
RETURNS TRIGGER AS $$
DECLARE
    project_name TEXT;
    member_id UUID;
BEGIN
    -- Get project name
    SELECT name INTO project_name FROM projects WHERE id = NEW.project_id;
    
    -- Create notification for each project member
    FOR member_id IN (SELECT user_id FROM project_members_direct WHERE project_id = NEW.project_id AND user_id != NEW.user_id)
    LOOP
        INSERT INTO notifications (user_id, title, content, type, related_id)
        VALUES (
            member_id, 
            'New post in ' || project_name,
            'A new post has been added to project ' || project_name,
            'post_created',
            NEW.id
        );
    END LOOP;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_on_post_creation
AFTER INSERT ON posts
FOR EACH ROW EXECUTE FUNCTION notify_on_post_creation();

-- Create notification when a comment is added
CREATE OR REPLACE FUNCTION notify_on_comment_creation()
RETURNS TRIGGER AS $$
DECLARE
    post_creator_id UUID;
    post_title TEXT;
BEGIN
    -- Get post creator
    SELECT user_id, SUBSTRING(content FROM 1 FOR 50) INTO post_creator_id, post_title 
    FROM posts WHERE id = NEW.post_id;
    
    -- Notify post creator if they didn't make the comment
    IF post_creator_id != NEW.user_id THEN
        INSERT INTO notifications (user_id, title, content, type, related_id)
        VALUES (
            post_creator_id,
            'New comment on your post',
            'Someone commented on your post: "' || post_title || '..."',
            'comment_added',
            NEW.id
        );
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_on_comment_creation
AFTER INSERT ON comments
FOR EACH ROW EXECUTE FUNCTION notify_on_comment_creation();

-- FIXED: Function to accept project invitation
CREATE OR REPLACE FUNCTION accept_project_invitation(invitation_code TEXT)
RETURNS UUID AS $$
DECLARE
    invitation_record project_invitations;
    user_id UUID;
    project_id UUID;
BEGIN
    -- Get invitation details
    SELECT * INTO invitation_record 
    FROM project_invitations 
    WHERE invite_code = invitation_code 
      AND accepted = FALSE 
      AND expires_at > NOW();
    
    IF invitation_record IS NULL THEN
        RAISE EXCEPTION 'Invalid or expired invitation';
    END IF;
    
    -- Get user ID by email
    SELECT id INTO user_id 
    FROM users 
    WHERE email = invitation_record.email;
    
    -- If user doesn't exist, raise exception
    IF user_id IS NULL THEN
        RAISE EXCEPTION 'User with this email does not exist, please create an account first';
    END IF;
    
    -- Add user to project
    INSERT INTO project_members (project_id, user_id, role)
    VALUES (invitation_record.project_id, user_id, invitation_record.role)
    ON CONFLICT (project_id, user_id) 
    DO UPDATE SET role = invitation_record.role;
    
    -- Update invitation status
    UPDATE project_invitations
    SET accepted = TRUE
    WHERE id = invitation_record.id;
    
    -- Return project ID
    project_id := invitation_record.project_id;
    RETURN project_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create notification when an invitation is accepted
CREATE OR REPLACE FUNCTION notify_on_invitation_acceptance()
RETURNS TRIGGER AS $$
DECLARE
    project_name TEXT;
    inviter_id UUID;
    user_email TEXT;
    user_name TEXT;
BEGIN
    IF NEW.accepted = TRUE AND OLD.accepted = FALSE THEN
        -- Get project name and inviter ID
        SELECT p.name, i.invited_by, u.email, u.full_name 
        INTO project_name, inviter_id, user_email, user_name
        FROM projects p
        JOIN project_invitations i ON p.id = i.project_id
        LEFT JOIN users u ON u.email = i.email
        WHERE i.id = NEW.id;
        
        -- Notify the person who sent the invitation
        INSERT INTO notifications (user_id, title, content, type, related_id)
        VALUES (
            inviter_id,
            'Invitation accepted',
            COALESCE(user_name, user_email) || ' has accepted your invitation to join ' || project_name,
            'invitation_accepted',
            NEW.id
        );
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_on_invitation_acceptance
AFTER UPDATE ON project_invitations
FOR EACH ROW EXECUTE FUNCTION notify_on_invitation_acceptance();

-- Création d'un type ENUM pour le statut des tâches
CREATE TYPE task_status AS ENUM ('not_started', 'in_progress', 'completed', 'delayed');

-- Création d'un type ENUM pour la priorité des tâches
CREATE TYPE task_priority AS ENUM ('low', 'medium', 'high');

-- Création de la table des tâches
CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    status task_status NOT NULL DEFAULT 'not_started',
    assigned_to UUID REFERENCES users(id) ON DELETE SET NULL,
    created_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    due_date TIMESTAMP WITH TIME ZONE,
    priority task_priority NOT NULL DEFAULT 'medium',
    completion_percentage INTEGER DEFAULT 0 CHECK (completion_percentage >= 0 AND completion_percentage <= 100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Création d'index pour améliorer les performances
CREATE INDEX idx_tasks_project_id ON tasks(project_id);
CREATE INDEX idx_tasks_assigned_to ON tasks(assigned_to);
CREATE INDEX idx_tasks_created_by ON tasks(created_by);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_due_date ON tasks(due_date);

-- Application du trigger pour mettre à jour automatiquement le champ updated_at
CREATE TRIGGER update_tasks_updated_at
BEFORE UPDATE ON tasks
FOR EACH ROW EXECUTE FUNCTION update_modified_column();

-- Activation de la sécurité au niveau des lignes (RLS)
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- Création des politiques de sécurité pour la table tasks

-- Politique de visibilité : les membres du projet peuvent voir les tâches
CREATE POLICY tasks_visibility ON tasks
    FOR SELECT
    USING (
        created_by = current_user_id() OR 
        assigned_to = current_user_id() OR
        is_project_member(project_id, current_user_id())
    );

-- Politique d'insertion : les membres du projet peuvent créer des tâches
CREATE POLICY tasks_insert ON tasks
    FOR INSERT
    WITH CHECK (
        created_by = current_user_id() AND
        is_project_member(project_id, current_user_id())
    );

-- Politique de mise à jour : l'utilisateur assigné ou les gestionnaires du projet peuvent mettre à jour les tâches
CREATE POLICY tasks_update ON tasks
    FOR UPDATE
    USING (
        assigned_to = current_user_id() OR 
        created_by = current_user_id() OR
        can_manage_project(project_id, current_user_id())
    );

-- Politique de suppression : seuls les gestionnaires du projet peuvent supprimer des tâches
CREATE POLICY tasks_delete ON tasks
    FOR DELETE
    USING (
        can_manage_project(project_id, current_user_id())
    );

-- Création d'une fonction pour mettre à jour automatiquement le statut en fonction du pourcentage d'achèvement
CREATE OR REPLACE FUNCTION update_task_status_based_on_completion()
RETURNS TRIGGER AS $$
BEGIN
    -- Si le pourcentage d'achèvement est modifié
    IF NEW.completion_percentage != OLD.completion_percentage THEN
        -- Si le pourcentage est à 100%, mettre le statut à 'completed'
        IF NEW.completion_percentage = 100 THEN
            NEW.status = 'completed';
        -- Si le pourcentage est supérieur à 0 mais inférieur à 100%, mettre le statut à 'in_progress'
        ELSIF NEW.completion_percentage > 0 THEN
            -- Ne pas changer le statut s'il est déjà 'delayed'
            IF NEW.status != 'delayed' THEN
                NEW.status = 'in_progress';
            END IF;
        -- Si le pourcentage est à 0, mettre le statut à 'not_started'
        ELSE
            -- Ne pas changer le statut s'il est déjà 'delayed'
            IF NEW.status != 'delayed' THEN
                NEW.status = 'not_started';
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Application du trigger pour mettre à jour automatiquement le statut
CREATE TRIGGER trigger_update_task_status
BEFORE UPDATE ON tasks
FOR EACH ROW EXECUTE FUNCTION update_task_status_based_on_completion();

-- Création d'une fonction pour vérifier les tâches en retard
CREATE OR REPLACE FUNCTION check_delayed_tasks()
RETURNS VOID AS $$
BEGIN
    -- Mettre à jour le statut des tâches dont la date d'échéance est passée et qui ne sont pas complétées
    UPDATE tasks
    SET status = 'delayed'
    WHERE due_date < NOW()
      AND status != 'completed'
      AND due_date IS NOT NULL;
END;
$$ LANGUAGE plpgsql;

-- Création d'une fonction pour obtenir les statistiques des tâches par projet
CREATE OR REPLACE FUNCTION get_project_task_stats(project_uuid UUID)
RETURNS TABLE (
    status task_status,
    count BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT t.status, COUNT(t.id)
    FROM tasks t
    WHERE t.project_id = project_uuid
    GROUP BY t.status;
END;
$$ LANGUAGE plpgsql;

-- Création d'une fonction pour obtenir les statistiques des tâches par utilisateur
CREATE OR REPLACE FUNCTION get_user_task_stats(user_uuid UUID)
RETURNS TABLE (
    status task_status,
    count BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT t.status, COUNT(t.id)
    FROM tasks t
    WHERE t.assigned_to = user_uuid
    GROUP BY t.status;
END;
$$ LANGUAGE plpgsql;

-- Commentaire explicatif
COMMENT ON TABLE tasks IS 'Stocke les tâches associées aux projets avec leur statut, priorité et assignation';
