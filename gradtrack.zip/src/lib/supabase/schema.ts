// تعريف أنواع البيانات لمشروع GradTrack

export interface User {
  id: string;
  email: string;
  role: 'student' | 'supervisor' | 'admin';
  full_name?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  owner_id: string;
  status: 'active' | 'archived' | 'completed'; // تمت إضافة حقل status مع القيم المحتملة
  created_at: string;
  updated_at: string;
}

export interface ProjectMember {
  id: string;
  project_id: string;
  user_id: string;
  role: 'owner' | 'supervisor' | 'member';
  created_at: string;
  user?: User;
}

export interface Post {
  id: string;
  project_id: string;
  user_id: string;
  content: string;
  code_snippet?: string;
  image_url?: string;
  created_at: string;
  updated_at: string;
  user?: User;
  comments?: Comment[];
  views_count?: number;
}

export interface PostView {
  id: string;
  post_id: string;
  user_id: string;
  viewed_at: string;
}

export interface Comment {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  code_snippet?: string;
  image_url?: string;
  created_at: string;
  updated_at: string;
  user?: User;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  content: string;
  type: 'post_created' | 'comment_added' | 'project_invitation' | 'inactivity_alert';
  related_id?: string;
  is_read: boolean;
  created_at: string;
}