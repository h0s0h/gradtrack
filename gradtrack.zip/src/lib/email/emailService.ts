import nodemailer from 'nodemailer';
import { Notification } from '@/lib/supabase/schema';

// إعداد مرسل البريد الإلكتروني
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASSWORD || '',
  },
});

// إرسال بريد إلكتروني
export async function sendEmail(to: string, subject: string, html: string): Promise<boolean> {
  try {
    const info = await transporter.sendMail({
      from: `"GradTrack" <${process.env.SMTP_USER}>`,
      to,
      subject,
      html,
    });
    console.log('Email sent successfully:', info.messageId);
    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
}

// إنشاء قالب البريد الإلكتروني برسالة تحقق الحساب بترحيب وشعرية
export function createEmailTemplate(notification: Notification, appUrl: string): string {
  const relatedLink = notification.related_id 
    ? `${appUrl}/project/${notification.related_id}` 
    : `${appUrl}/dashboard`;

  // تخصيص عنوان الزر حسب نوع الإشعار
  let buttonText = 'عرض التفاصيل';
  if (notification.type === 'project_invitation') {
    buttonText = 'عرض المشروع';
  } else if (notification.type === 'post_created') {
    buttonText = 'عرض المنشور';
  } else if (notification.type === 'comment_added') {
    buttonText = 'عرض التعليق';
  }

  return `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${notification.title}</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          margin: 0;
          padding: 0;
          background-color: #f0f4f8;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #fff;
          border-radius: 8px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #4f46e5;
          color: white;
          padding: 20px;
          text-align: center;
          border-radius: 8px 8px 0 0;
        }
        .content {
          padding: 20px;
        }
        .footer {
          text-align: center;
          padding: 15px;
          font-size: 12px;
          color: #6b7280;
        }
        .button {
          display: inline-block;
          background-color: #4f46e5;
          color: white;
          text-decoration: none;
          padding: 10px 20px;
          border-radius: 5px;
          margin-top: 20px;
          transition: background-color 0.3s;
        }
        .button:hover {
          background-color: #3730a3;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <!-- ترويسة الرسالة -->
        <div class="header">
          <h1>إشعار من GradTrack</h1>
        </div>
        <!-- محتوى الرسالة -->
        <div class="content">
          <h2>${notification.title}</h2>
          <p>أسعد الله أوقاتك،</p>
          <p>${notification.content}</p>
          <a href="${relatedLink}" class="button">${buttonText}</a>
        </div>
        <!-- تذييل الرسالة -->
        <div class="footer">
          <p>هذه رسالة تلقائية من منصة GradTrack. يُرجى عدم الرد عليها.</p>
          <p>&copy; ${new Date().getFullYear()} GradTrack. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

// إرسال إشعار بريدي مع معالجة أفضل للأخطاء
export async function sendNotificationEmail(
  to: string,
  notification: Notification,
  appUrl: string = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
): Promise<boolean> {
  try {
    const emailHtml = createEmailTemplate(notification, appUrl);
    const result = await sendEmail(to, notification.title, emailHtml);
    
    if (!result) {
      console.error(`Failed to send email notification to ${to}`);
    }
    
    return result;
  } catch (error) {
    console.error('Error in sendNotificationEmail:', error);
    return false;
  }
}