import { supabase } from '@/lib/supabase/client';
import { User, Notification } from '@/lib/supabase/schema';
import { sendNotificationEmail } from '@/lib/email/emailService';

// إنشاء إشعار جديد
export async function createNotification(
  userId: string,
  title: string,
  content: string,
  type: 'post_created' | 'comment_added' | 'project_invitation' | 'inactivity_alert',
  relatedId?: string
): Promise<{ success: boolean; notification?: Notification; error?: string }> {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .insert({
        user_id: userId,
        title,
        content,
        type,
        related_id: relatedId,
        is_read: false,
        created_at: new Date().toISOString() // إضافة تاريخ الإنشاء صراحةً
      })
      .select()
      .single();

    if (error) throw error;

    return { success: true, notification: data as Notification };
  } catch (error) {
    console.error('Error creating notification:', error);
    return { success: false, error: 'حدث خطأ أثناء إنشاء الإشعار' };
  }
}

// جلب إشعارات المستخدم لعرضها داخل المشروع
export async function getUserNotifications(
  userId: string,
  limit: number = 20,
  offset: number = 0,
  onlyUnread: boolean = false
): Promise<{ notifications: Notification[]; count: number }> {
  try {
    // بناء الاستعلام الأساسي
    let query = supabase
      .from('notifications')
      .select('*', { count: 'exact' })
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    // إضافة فلتر للإشعارات غير المقروءة إذا تم تحديد ذلك
    if (onlyUnread) {
      query = query.eq('is_read', false);
    }
    
    const { data, error, count } = await query;
    
    if (error) throw error;
    
    return { 
      notifications: data as Notification[], 
      count: count || 0 
    };
  } catch (error) {
    console.error('Error fetching user notifications:', error);
    return { notifications: [], count: 0 };
  }
}

// تحديث حالة قراءة الإشعار
export async function markNotificationAsRead(
  notificationId: string,
  isRead: boolean = true
): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: isRead })
      .eq('id', notificationId);
    
    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error updating notification read status:', error);
    return false;
  }
}

// تحديث حالة قراءة جميع إشعارات المستخدم
export async function markAllNotificationsAsRead(userId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', userId)
      .eq('is_read', false);
    
    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    return false;
  }
}

// إرسال إشعار عند إنشاء منشور جديد
export async function notifyNewPost(
  postId: string,
  projectId: string,
  authorId: string,
  authorName: string,
  projectName: string,
  sendEmail: boolean = true
): Promise<void> {
  try {
    // جلب المشرفين وأعضاء المشروع (باستثناء المؤلف)
    const { data: members, error: membersError } = await supabase
      .from('project_members')
      .select('user_id, role, users:user_id(email, full_name)')
      .eq('project_id', projectId)
      .neq('user_id', authorId);

    if (membersError) throw membersError;

    // إنشاء إشعارات لكل عضو
    for (const member of members || []) {
      if (!member.user_id) continue; // تخطي العناصر التي ليس لها معرف مستخدم
      
      const title = 'منشور جديد في المشروع';
      const content = `قام ${authorName} بنشر تحديث جديد في مشروع "${projectName}"`;

      const { success, notification } = await createNotification(
        member.user_id,
        title,
        content,
        'post_created',
        postId
      );

      // إرسال بريد إلكتروني إذا كان مطلوباً وكان العضو مشرفاً
      if (success && sendEmail && notification && member.users?.email) {
        const emailSent = await sendNotificationEmail(
          member.users.email,
          notification
        );
        
        console.log(`Email notification for new post sent to ${member.users.email}: ${emailSent ? 'Success' : 'Failed'}`);
      }
    }
  } catch (error) {
    console.error('Error notifying about new post:', error);
  }
}

// إرسال إشعار عند إضافة تعليق جديد
export async function notifyNewComment(
  commentId: string,
  postId: string,
  authorId: string,
  authorName: string,
  postAuthorId: string,
  projectName: string,
  sendEmail: boolean = true
): Promise<void> {
  try {
    // إذا كان مؤلف التعليق هو نفسه مؤلف المنشور، فلا داعي للإشعار
    if (authorId === postAuthorId) return;

    // جلب معلومات مؤلف المنشور
    const { data: postAuthor, error: authorError } = await supabase
      .from('users')
      .select('email, full_name')
      .eq('id', postAuthorId)
      .single();

    if (authorError) throw authorError;

    const title = 'تعليق جديد على منشورك';
    const content = `قام ${authorName} بالتعليق على منشورك في مشروع "${projectName}"`;

    const { success, notification } = await createNotification(
      postAuthorId,
      title,
      content,
      'comment_added',
      postId // استخدام معرف المنشور وليس التعليق لتسهيل الانتقال إلى المنشور مع التعليق
    );

    // إرسال بريد إلكتروني إذا كان مطلوباً
    if (success && sendEmail && notification && postAuthor?.email) {
      const emailSent = await sendNotificationEmail(
        postAuthor.email,
        notification
      );
      
      console.log(`Email notification for new comment sent to ${postAuthor.email}: ${emailSent ? 'Success' : 'Failed'}`);
    }
  } catch (error) {
    console.error('Error notifying about new comment:', error);
  }
}

// إرسال إشعار عند إضافة مستخدم إلى مشروع
export async function notifyProjectInvitation(
  projectId: string,
  userId: string,
  projectName: string,
  inviterName: string,
  role: string,
  sendEmail: boolean = true
): Promise<void> {
  try {
    // جلب معلومات المستخدم المضاف
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('email, full_name')
      .eq('id', userId)
      .single();

    if (userError) throw userError;

    const roleText = role === 'supervisor' ? 'مشرف' : 'عضو';
    const title = 'تمت إضافتك إلى مشروع جديد';
    const content = `قام ${inviterName} بإضافتك كـ${roleText} في مشروع "${projectName}"`;

    const { success, notification } = await createNotification(
      userId,
      title,
      content,
      'project_invitation',
      projectId
    );

    // إرسال بريد إلكتروني إذا كان مطلوباً
    if (success && sendEmail && notification && user?.email) {
      const emailSent = await sendNotificationEmail(
        user.email,
        notification
      );
      
      console.log(`Email notification for project invitation sent to ${user.email}: ${emailSent ? 'Success' : 'Failed'}`);
    }
  } catch (error) {
    console.error('Error notifying about project invitation:', error);
  }
}

// إرسال إشعار عند عدم النشاط لفترة طويلة
export async function notifyInactivity(
  projectId: string,
  userId: string,
  projectName: string,
  inactiveDays: number,
  sendEmail: boolean = true
): Promise<void> {
  try {
    // جلب معلومات المستخدم
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('email, full_name')
      .eq('id', userId)
      .single();

    if (userError) throw userError;

    // جلب المشرفين على المشروع
    const { data: supervisors, error: supervisorsError } = await supabase
      .from('project_members')
      .select('user_id, users:user_id(email, full_name)')
      .eq('project_id', projectId)
      .eq('role', 'supervisor');

    if (supervisorsError) throw supervisorsError;

    // إنشاء إشعار للمستخدم
    const title = 'تذكير بتحديث المشروع';
    const content = `لم تقم بنشر أي تحديثات في مشروع "${projectName}" منذ ${inactiveDays} يوم. يرجى تحديث تقدمك.`;

    const { success, notification } = await createNotification(
      userId,
      title,
      content,
      'inactivity_alert',
      projectId
    );

    // إرسال بريد إلكتروني للمستخدم إذا كان مطلوباً
    if (success && sendEmail && notification && user?.email) {
      const emailSent = await sendNotificationEmail(
        user.email,
        notification
      );
      
      console.log(`Email notification for inactivity sent to ${user.email}: ${emailSent ? 'Success' : 'Failed'}`);
    }

    // إنشاء إشعارات للمشرفين
    for (const supervisor of supervisors || []) {
      if (!supervisor.user_id || supervisor.user_id === userId) continue; // تخطي إذا كان المشرف هو نفسه المستخدم غير النشط أو إذا لم يكن هناك معرف مستخدم

      const supervisorTitle = 'تنبيه عدم نشاط طالب';
      const supervisorContent = `لم يقم ${user?.full_name || 'الطالب'} بنشر أي تحديثات في مشروع "${projectName}" منذ ${inactiveDays} يوم.`;

      const { success: supSuccess, notification: supNotification } = await createNotification(
        supervisor.user_id,
        supervisorTitle,
        supervisorContent,
        'inactivity_alert',
        projectId
      );

      // إرسال بريد إلكتروني للمشرف إذا كان مطلوباً
      if (supSuccess && sendEmail && supNotification && supervisor.users?.email) {
        const emailSent = await sendNotificationEmail(
          supervisor.users.email,
          supNotification
        );
        
        console.log(`Email notification for inactivity (to supervisor) sent to ${supervisor.users.email}: ${emailSent ? 'Success' : 'Failed'}`);
      }
    }
  } catch (error) {
    console.error('Error notifying about inactivity:', error);
  }
}